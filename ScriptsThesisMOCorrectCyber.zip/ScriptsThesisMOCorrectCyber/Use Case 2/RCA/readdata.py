import numpy as np
from array import array
import pandas as pd
from scipy import stats
# Plot the correlation matrix
import seaborn as sns
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import statistics as st
from sklearn.utils import resample
from sklearn.linear_model import LogisticRegression
import warnings
from sklearn.model_selection import GridSearchCV
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import OrdinalEncoder
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.preprocessing import StandardScaler
# Suppress all DeprecationWarnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
#import tensorflow
#from tensorflow.keras import layers, models
#from tensorflow.keras.utils import plot_model
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.neural_network import MLPClassifier
from sklearn.model_selection import train_test_split
from sklearn.model_selection import cross_val_score, KFold, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report

from xgboost import XGBClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import StandardScaler
import numpy as np

df = pd.read_csv(r'C:\Users\20172671\Downloads\Semaku\rootcause\agent_variables.txt', engine='python')
df = df.sort_values('OwnID')
#print(df)
#print(df.to_numpy(dtype=str))
OwnID =df["OwnID"]
CreationTimeLM=df["CreationTimeLM"]
StartTimeWBDL=df["StartTimeWBDL"]
EndTimeWBDL=df["EndTimeWBDL"]
EndTimeDL=df["EndTimeDL"]
TimeWBDL=df["TimeWBDL"]
TimeDL=df["TimeDL"]
DLWBID=df["DLWBID"]
LotQuality=df["LotQuality"]
StartTimeDBDL=df["StartTimeDBDL"]
EndTimeDBDL=df["EndTimeDBDL"]
TimeDBDL=df["TimeDBDL"]
DLBID=df["DLBID"]
LotQualityT2=df["LotQualityT2"]
#print(OwnID)
OwnIDArray=OwnID.to_numpy(dtype=str)
OwnIDInt = list(map(int, OwnIDArray))
#print(OwnIDInt)
LotQualityArray=LotQuality.to_numpy(dtype=str)
LotQualityInt = list(map(int, LotQualityArray))
#print(LotQualityInt)
TimeWBDLArray=TimeWBDL.to_numpy(dtype=str)
TimeWBDLInt = list(map(int, TimeWBDLArray))
#print(TimeWBDLInt)
#QuantifiedTimeWBDL=list(map(lambda x: x/10000, TimeWBDLInt))
#print("QuantifiedTimeWBDL:", QuantifiedTimeWBDL)
#print("CreationTimeLM:", CreationTimeLM)
#print("StartTimeWBDL:", StartTimeWBDL)
#print("EndTimeWBDL:", EndTimeWBDL)
#print("EndTimeDL:", EndTimeDL)
#print("TimeWBDL:", TimeWBDL)
#print("TimeDL:", TimeDL)
#print("DLWBID:", DLWBID)
#print("LotQualityWB:", LotQuality)
#print("StartTimeDBDL:", StartTimeDBDL)
#print("EndTimeDBDL:", EndTimeDBDL)
#print("TimeDBDL:", TimeDBDL)
#print("DLBID:", DLBID)
print("OwnID:", OwnIDInt)
StartTimeWBDLArray=StartTimeWBDL.to_numpy(dtype=str)
StartTimeWBDLInt = list(map(int, StartTimeWBDLArray))
print("StartTimeWBDL:", StartTimeWBDLInt)
EndTimeWBDLArray=EndTimeWBDL.to_numpy(dtype=str)
EndTimeWBDLInt = list(map(int, EndTimeWBDLArray))
print("EndTimeWBDL:", EndTimeWBDLInt)
TimeWBDLArray=TimeWBDL.to_numpy(dtype=str)
TimeWBDLInt = list(map(int, TimeWBDLArray))
print("TimeWBDL:", TimeWBDLInt)
LotQualityArray=LotQuality.to_numpy(dtype=str)
LotQualityInt = list(map(int, LotQualityArray))
print("LotQualityWB:", LotQualityInt)
DLWBIDArray=DLWBID.to_numpy(dtype=str)
DLWBIDInt = list(map(int, DLWBIDArray))
print("DLWBID:", DLWBIDInt)
StartTimeDBDLArray=StartTimeDBDL.to_numpy(dtype=str)
StartTimeDBDLInt = list(map(int, StartTimeDBDLArray))
print("StartTimeDBDL:", StartTimeDBDLInt)
EndTimeDBDLArray=EndTimeDBDL.to_numpy(dtype=str)
EndTimeDBDLInt = list(map(int, EndTimeDBDLArray))
print("EndTimeDBDL:", EndTimeDBDLInt)
TimeDBDLArray=TimeDBDL.to_numpy(dtype=str)
TimeDBDLInt = list(map(int, TimeDBDLArray))
print("TimeDBDL:", TimeDBDLInt)
DLBIDArray=DLBID.to_numpy(dtype=str)
DLBIDInt = list(map(int, DLBIDArray))
print("DLBID:", DLBIDInt)
#print("LotQualityDB:", LotQualityT2)
LotQualityT2Array=LotQualityT2.to_numpy(dtype=str)
LotQualityT2Int = list(map(int, LotQualityT2Array))
print("LotQualityDB:", LotQualityT2Int)
EndTimeDLArray=EndTimeDL.to_numpy(dtype=str)
EndTimeDLInt = list(map(int, EndTimeDLArray))
print("EndTimeDL:", EndTimeDLInt)
TimeDLArray=TimeDL.to_numpy(dtype=str)
TimeDLInt = list(map(int, TimeDLArray))
print("TimeDL:", TimeDLInt)
LotQualityAverage=(LotQualityT2+LotQuality)/2
LotQualityAverageArray=LotQualityAverage.to_numpy(dtype=float)
LQAInt=list(map(float, LotQualityAverageArray))
print("LotQualityAverage:", LQAInt)




print("TimeDL Mean:", st.mean(TimeDLInt))
print("TimeDL Dev:", st.stdev(TimeDLInt))
print("TimeDBDL Mean:", st.mean(TimeDBDLInt))
print("TimeDBDL Dev:", st.stdev(TimeDBDLInt))
print("TimeWBDL Mean:", st.mean(TimeWBDLInt))
print("TimeWBDL Dev:", st.stdev(TimeWBDLInt))





Machine1=DLWBIDInt
Machine2=DLBIDInt
Machine3=[]
MachineCombo=[]
for i in range(len(Machine1)):
    combined_value = str(Machine1[i]) + str(Machine2[i])
    Machine3.append(combined_value)
Machine3 = list(map(int, Machine3))


#11 =1, 12= 2, 21= 3, 22= 4
for i in Machine3:
    if i==11:
        MachineCombo.append(1);
    elif i==12:
        MachineCombo.append(2)
    elif i==21:
        MachineCombo.append(3)
    elif i==22:
        MachineCombo.append(4)
        

MachineComboCounts = pd.Series(MachineCombo).value_counts()
TotalMachineComboCount = len(MachineCombo)
MachineComboPercentages = (MachineComboCounts / TotalMachineComboCount) * 100
print("\nPercentage of each MachineCombo:")
for i in range(1, 5):
    if i in MachineComboPercentages:
        print(f"MachineCombo {i}: {MachineComboPercentages[i]:.2f}%")
    else:
        print(f"MachineCombo {i}: 0.00%")
#print("MachineCombo:", MachineCombo)
#TimeWBDL higher=1, TimeDBDL higher=2
DominantTask=[]
for i in range(len(TimeWBDLInt)):
    if TimeWBDLInt[i] >TimeDBDLInt[i]:
        DominantTask.append(1)
    else:
        DominantTask.append(2)
#print("TimeDBDL:", TimeDBDLInt)
#print("TimeWBDL:", TimeWBDLInt)
print("LotQualityAverage:", LotQualityAverageArray)
print("TimeDL:", TimeDLInt)
print("DominantTask:", DominantTask)        
# print("DLWBID:", DLWBIDInt)
# print("DLBBID:", DLBIDInt)
#T1M1=1, T1M2=2, T2M1=3, T2M2=4
TaskMachineCombo=[]
for i in range(len(DominantTask)):
    if DominantTask[i] ==1:
        if DLWBIDInt[i]==1:
            TaskMachineCombo.append(1)
        elif DLWBIDInt[i]==2:
            TaskMachineCombo.append(2)
    elif DominantTask[i] ==2:
        if DLWBIDInt[i]==1:
            TaskMachineCombo.append(3)
        elif DLWBIDInt[i]==2:
            TaskMachineCombo.append(4)
            
df['TaskMachineCombo'] = TaskMachineCombo


def GetTaskMachineQualityCombo(row):
    if row['TaskMachineCombo'] == 1:
        taskmachine = 'T1M1'
        quality = row['LotQuality']
    elif row['TaskMachineCombo'] == 2:
        taskmachine = 'T1M2'
        quality = row['LotQuality']
    elif row['TaskMachineCombo'] == 3:
        taskmachine = 'T2M1'
        quality = row['LotQualityT2']
    elif row['TaskMachineCombo'] == 4:
        taskmachine = 'T2M2'
        quality = row['LotQualityT2']
    else:
        return None
    
    if quality == 1:
        qualitystr = 'Q1'
    elif quality == 2:
        qualitystr = 'Q2'
    elif quality == 3:
        qualitystr = 'Q3'
    else:
        return None 
    return f"{taskmachine}_{qualitystr}"

df['TaskMachineQualityCombo'] = df.apply(GetTaskMachineQualityCombo, axis=1)

orderedcombos = [
    'T1M1_Q1', 'T1M1_Q2', 'T1M1_Q3',
    'T1M2_Q1', 'T1M2_Q2', 'T1M2_Q3',
    'T2M1_Q1', 'T2M1_Q2', 'T2M1_Q3',
    'T2M2_Q1', 'T2M2_Q2', 'T2M2_Q3'
]
MeanTimes = df.groupby('TaskMachineQualityCombo').mean()
TotalCount = len(df)
TaskMachinQualityCounts = df['TaskMachineQualityCombo'].value_counts()
TaskMachineQualityPercentages = (TaskMachinQualityCounts / TotalCount) * 100

print("\nPercentage of each TaskMachineQualityCombo:")
for combo in orderedcombos:
    if combo in TaskMachineQualityPercentages:
        print(f"{combo}: {TaskMachineQualityPercentages[combo]:.2f}%")
    else:
        print(f"{combo}: 0.00%")

print("\nMean times for each TaskMachineQualityCombo:")
print(MeanTimes[['TimeWBDL', 'TimeDBDL', 'TimeDL']])  # Replace columns with relevant ones if needed


print("TaskMachineCombo:", TaskMachineCombo)

LotQualityCounts = pd.Series(LotQualityInt).value_counts(normalize=True) * 100
print("Percentage of LotQuality (1, 2, 3):")
print(LotQualityCounts)

LotQualityT2Counts = pd.Series(LotQualityT2Int).value_counts(normalize=True) * 100
print("\nPercentage of LotQualityT2 (1, 2, 3):")
print(LotQualityT2Counts)

TaskMachineComboCounts = pd.Series(TaskMachineCombo).value_counts(normalize=True) * 100
print("\nPercentage of TaskMachineCombo (1, 2, 3, 4):")
print(TaskMachineComboCounts)

DLWBIDCounts = pd.Series(DLWBIDInt).value_counts(normalize=True) * 100
print("\nPercentage of (DLWBIDInt) (1, 2):")
print(DLWBIDCounts)

DLBIDCounts = pd.Series(DLBIDInt).value_counts(normalize=True) * 100
print("\nPercentage of (DLBIDInt) (1, 2):")
print(DLBIDCounts)

TaskMachineQualityCombo=df['TaskMachineQualityCombo']
data = {
    'TaskMachineCombo': TaskMachineCombo,
    'TaskMachineQualityCombo': TaskMachineQualityCombo,
    'TimeWBDL': TimeWBDLInt,
    'TimeDL': TimeDLInt,
    'TimeDBDL': TimeDBDLInt,
    'OwnID': OwnIDInt,
    'LotQuality': LotQualityInt,
    'LotQualityT2': LotQualityT2Int,
    'DLWBID': DLWBIDInt,
    'DLDBID': DLBIDInt,
    'LotQualityAverage': LQAInt
}


df2 = pd.DataFrame(data)
print("df2b4",len(df2))
print(df2['TaskMachineQualityCombo'].value_counts())
df2["rare"] = df2['TaskMachineQualityCombo'].isin(
    df2['TaskMachineQualityCombo'].value_counts()[lambda x: x.isin([1,2])].index
)

rare = df2[df2['rare']]
rareid = rare['OwnID'].unique()
if rare.size > 0:  
    df2= df2[~df2['OwnID'].isin(rareid)]
else:
    df2 = df2.copy()  
print("df2a4",len(df2))
df2=df2.drop(["rare"], axis=1)

# df2.drop(["TaskMachineCombo"], axis=1)
# normalclasses = df2[~df2.index.isin(rareclasses.index)]

# rareclassesoversample = resample(rareclasses, 
#                                     replace=True, 
#                                     n_samples=6,  
#                                     random_state=1)

# df2 = pd.concat([normalclasses, rareclassesoversample])

# print(df2['TaskMachineQualityCombo'].value_counts())
# rareclasses = df2[df2['TaskMachineQualityCombo'].isin(
#     df2['TaskMachineQualityCombo'].value_counts()[lambda x: x == 2].index
# )]
# normalclasses = df2[~df2.index.isin(rareclasses.index)]

# rareclassesoversample = resample(rareclasses, 
#                                     replace=True, 
#                                     n_samples=6,  
#                                     random_state=1)

# df2 = pd.concat([normalclasses, rareclassesoversample])
# print(df2['TaskMachineQualityCombo'].value_counts())

#Split data
TrainData=df2.drop(["TaskMachineCombo"], axis=1)
TargetData=df2[["TaskMachineCombo"]]
Xtrainval, Xtest, Ytrainval, Ytest, Ztrainval, Ztest = train_test_split(TrainData, TargetData, df2['TaskMachineQualityCombo'], test_size=0.15, random_state=1)



Xtrain, Xval, Ytrain, Yval, Ztrain, Zval = train_test_split(
    Xtrainval, Ytrainval, Ztrainval, 
    test_size=0.176, random_state=1, stratify=Ztrainval
)
OgXtest=Xtest.copy()
OgXtest=OgXtest.drop(["TaskMachineQualityCombo","TimeWBDL","TimeDBDL","LotQuality", "LotQualityT2","DLDBID","DLWBID","OwnID"], axis=1)
dftrain = Xtrain.copy()
dftrain['TaskMachineCombo'] = Ytrain
dftrain['TaskMachineQualityCombo'] = Ztrain


#Outlier removal

dftrain['SetupTime'] = dftrain['TimeDL'] - dftrain['TimeWBDL'] - dftrain['TimeDBDL']
z=(dftrain['SetupTime']-st.mean(dftrain['SetupTime']))/st.stdev(dftrain['SetupTime'])
print("zsetup", z)
dftrain['ZscoreSetup'] = (dftrain['SetupTime']-st.mean(dftrain['SetupTime']))/st.stdev(dftrain['SetupTime'])
Zthreshold = 3
dftrain['Outlier'] = dftrain['ZscoreSetup'].apply(lambda z: abs(z) > Zthreshold)
OutliersSetup = dftrain[dftrain['Outlier']]
if not OutliersSetup.empty:
    print("\nOutliers Detected:")
    print(OutliersSetup[['OwnID', 'SetupTime', 'ZscoreSetup']])
else:
    print("\nNo outliers detected.")

def CalculateGroupedZOutliers(dftrain, column, qualitycolumn, Zthreshold=3):
    outliers = []
    grouped = dftrain.groupby(['TaskMachineQualityCombo', qualitycolumn])   
    for name, group in grouped:
        group = group.dropna(subset=[column])     
        mean = group[column].mean()
        std = group[column].std()
        if std == 0 or np.isnan(std):
            continue
        group['ZScore'] = (group[column] - mean) / std
        outlier_rows = group[np.abs(group['ZScore']) > Zthreshold].copy() 
        if not outlier_rows.empty:
            outliers.append(outlier_rows)
    return pd.concat(outliers, ignore_index=True) if outliers else pd.DataFrame()

OutliersWBDL = CalculateGroupedZOutliers(dftrain, 'TimeWBDL', 'LotQuality')
OutliersDBDL = CalculateGroupedZOutliers(dftrain, 'TimeDBDL', 'LotQualityT2')
print("\nOutliers for TimeWBDL:")
print(OutliersWBDL if not OutliersWBDL.empty else "No outliers found")
print("\nOutliers for TimeDBDL:")
print(OutliersDBDL if not OutliersDBDL.empty else "No outliers found")

CombineOutliers = pd.concat([OutliersWBDL, OutliersDBDL, OutliersSetup], ignore_index=True)

if CombineOutliers.empty:
    print("\nNo outliers found.")
    OutlierIDs = []  
else:
    print(CombineOutliers.to_string(index=False))
    OutlierIDs = CombineOutliers['OwnID'].unique()
    print("\nOutliers removed (OwnIDs):", OutlierIDs)

if OutlierIDs.size > 0:
    dftrain= dftrain[~dftrain['OwnID'].isin(OutlierIDs)]
else:
    dftrain = dftrain.copy()  

if not dftrain.empty:
    # LotQuality (1, 2, 3)
    LotQualityCountsAfter = dftrain['LotQuality'].value_counts(normalize=True) * 100
    print("\nPercentage of LotQuality (1, 2, 3) after outlier removal:")
    print(LotQualityCountsAfter)
    
    # LotQualityT2 (1, 2, 3)
    LotQualityT2CountsAfter = dftrain['LotQualityT2'].value_counts(normalize=True) * 100
    print("\nPercentage of LotQualityT2 (1, 2, 3) after outlier removal:")
    print(LotQualityT2CountsAfter)
    
    # TaskMachineCombo (1, 2, 3, 4)
    TaskMachineComboCountsAfter = dftrain['TaskMachineCombo'].value_counts(normalize=True) * 100
    print("\nPercentage of TaskMachineCombo (1, 2, 3, 4) after outlier removal:")
    print(TaskMachineComboCountsAfter)
else:
    print("\nNo data to recalculate percentages after outlier removal.")

if 'dftrain' in locals() and not dftrain.empty:
    TaskMachineQualityPercentagesAfter = (
        dftrain['TaskMachineQualityCombo'].value_counts(normalize=True) * 100
    )
    print("\nPercentage of each TaskMachineQualityCombo after outlier removal:")
    for combo in orderedcombos:
        percentage = TaskMachineQualityPercentagesAfter.get(combo, 0)  
else:
    print("\nNo cleaned data available to calculate percentages.")
print(len(dftrain))
if 'dftrain' in locals() and not dftrain.empty:
    MeanTimeDL = dftrain['TimeDL'].mean()
    MeanTimeWBDL = dftrain['TimeWBDL'].mean()
    MeanTimeDBDL = dftrain['TimeDBDL'].mean()

    print("\nMeans of columns after outlier removal:")
    print(f"Mean of TimeDL: {MeanTimeDL:.2f}")
    print(f"Mean of TimeWBDL: {MeanTimeWBDL:.2f}")
    print(f"Mean of TimeDBDL: {MeanTimeDBDL:.2f}")
else:
    print("\nDataFrame 'dftrain' is not defined or empty.")

colors = plt.cm.get_cmap('tab20', len(orderedcombos))
taskcolormap = {combo: colors(i) for i, combo in enumerate(orderedcombos)}
dftrain['TaskMachineQualityCombo'] = pd.Categorical(dftrain['TaskMachineQualityCombo'], categories=orderedcombos, ordered=True)
dftrain.sort_values('TaskMachineQualityCombo', inplace=True)
plt.figure(figsize=(15, 10))
plt.xscale('log')
plt.yscale('log')
for combo in orderedcombos:
    subset = dftrain[dftrain['TaskMachineQualityCombo'] == combo]
    if not subset.empty:
        plt.scatter(
            subset['TimeWBDL'], 
            subset['TimeDBDL'], 
            s=30,  
            color=taskcolormap[combo], 
            label=f'{combo}', 
            alpha=0.6  
        )

if not CombineOutliers.empty:
    plt.scatter(
        CombineOutliers['TimeWBDL'],
        CombineOutliers['TimeDBDL'],
        c=CombineOutliers['TaskMachineQualityCombo'].map(taskcolormap),
        edgecolor='black',
        linewidth=1.5,
        s=100,
        label='Outliers'
    )

# Add labels, title, and legend
plt.xlabel('TimeWBDL (ms)', fontsize=14)
plt.ylabel('TimeDBDL (ms)', fontsize=14)
plt.title('Logarithmic scatter plot of outliers per TaskMachineQualityCombo on the training data', fontsize=16)
plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left', fontsize=10)
plt.grid(color='gray', linestyle='--', linewidth=0.5, alpha=0.7)
plt.tight_layout()
plt.show()

#Rebuild Xtrain, leave in the target for the correlation matrix
Xtrain = dftrain.drop(["TaskMachineQualityCombo",'ZscoreSetup', "Outlier", "SetupTime", "OwnID"], axis=1)
Ytrain=dftrain[["TaskMachineCombo"]]
Ztrain=dftrain["TaskMachineQualityCombo"]
print(Xtrain.head())
#preprocess data

#interesting data
#output TaskMachineCombo
#input test LotQualityAverage, TimeDL
#train DLWBID, DLBID, LotQuality, LotQualityT2, TimeWBDL, TimeDBDL, TaskMachineCombo, LotQualityAverage, TimeDL
# Preprocessing
# Ordinal encoding for LotQuality and LotQualityT2
encoder1 = OrdinalEncoder()
Xtrain[['LotQuality', 'LotQualityT2']] = encoder1.fit_transform(Xtrain[['LotQuality', 'LotQualityT2']])

# Standardize numerical features
scaler = StandardScaler()
Xtrain[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']] = scaler.fit_transform(Xtrain[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']])

encoder2 = LabelEncoder()
encoder3 = LabelEncoder()
encoder4 = LabelEncoder()
# For DLWBID
Xtrain['DLWBID'] = encoder2.fit_transform(Xtrain['DLWBID'])

# For DLBID
Xtrain['DLDBID'] = encoder3.fit_transform(Xtrain['DLDBID'])
Xtrain['TaskMachineCombo'] = encoder4.fit_transform(Xtrain['TaskMachineCombo'])

pd.set_option('display.max_rows', None)  
pd.set_option('display.max_columns', None)  
pd.set_option('display.width', None)  
pd.set_option('display.max_colwidth', None)  #
pd.reset_option('display.max_rows')
pd.reset_option('display.max_columns')
pd.reset_option('display.width')
pd.reset_option('display.max_colwidth')


# df2.drop(columns=["LotQualityT2", "TimeDBDL", "DLDBID", "Outlier", "TimeWBDL", "DLWBID", "LotQuality"], inplace=True)
# scaler = StandardScaler()
Xinputs = Xtrain[['TimeDL', 'LotQualityAverage']]

OgXtrain=Xinputs
regwbdl = LinearRegression().fit(Xinputs,  Xtrain['TimeWBDL'])
regdbdl = LinearRegression().fit(Xinputs,  Xtrain['TimeDBDL'])
reglq1 = LinearRegression().fit(Xinputs,  Xtrain['LotQuality'])
reglq2 = LinearRegression().fit(Xinputs,  Xtrain['LotQualityT2'])
regdw = LinearRegression().fit(Xinputs,  Xtrain['DLWBID'])
regdb = LinearRegression().fit(Xinputs,  Xtrain['DLDBID'])
regwbdl = LogisticRegression().fit(Xinputs, Xtrain['DLWBID'])
regdbdl = LogisticRegression().fit(Xinputs, Xtrain['DLDBID'])
# Create an approximation of TimeWBDL
# Xtrain['TimeWBDLApproximation'] = regwbdl.predict(Xinputs)
# Xtrain['TimeDBDLApproximation'] = regdbdl.predict(Xinputs)
# Xtrain['LotQualityApproximation'] = reglq1.predict(Xinputs)
# Xtrain['LotQualityT2Approximation'] = reglq2.predict(Xinputs)
Xtrain['DLWBIDApproximation'] = regdw.predict(Xinputs)
# Xtrain['DLDBIDApproximation'] = regdb.predict(Xinputs)

# Xtrain['TimeDLTimesLQA'] = Xtrain['TimeDL'] * Xtrain['LotQualityAverage']
# Xtrain['TimeDLSquared'] = Xtrain['TimeDL'] ** 2
# Xtrain['LQASquared'] = Xtrain['LotQualityAverage'] ** 2
# Xtrain['TimeDLLQARatio'] = Xtrain['TimeDL'] / (Xtrain['LotQualityAverage'] + 1e-5)



FeaturestoScale = [
    "DLWBIDApproximation"]

scaler2 = StandardScaler()
Xtrain[FeaturestoScale] = scaler2.fit_transform(Xtrain[FeaturestoScale])

ColumnsDrop = ["TimeWBDL", "TimeDBDL", "LotQuality", "LotQualityT2", "DLWBID", "DLDBID"]
#,"TimeDLLQARatio","LQASquared", "TimeDLSquared", "TimeDLTimesLQA", "LotQualityApproximation", "LotQualityAverage", "TimeWBDLApproximation", "TimeDBDLApproximation", "DLDBIDApproximation"

ColumnsToDrop = [col for col in ColumnsDrop if col in Xtrain.columns]

Xtrain.drop(columns=ColumnsToDrop, inplace=True)

NumericalFeatures = Xtrain.select_dtypes(include=['float64', 'int64'])
CorrelationMatrix = NumericalFeatures.corr()
DesiredOrder = ['TaskMachineCombo', 'TimeDL', 'LotQualityAverage', 'TimeWBDL', 'TimeDBDL']
ExistingColumns = [col for col in DesiredOrder if col in CorrelationMatrix.columns]
RemainingColumns = [col for col in CorrelationMatrix.columns if col not in ExistingColumns]
FinalOrder = ExistingColumns + RemainingColumns
CorrelationMatrix = CorrelationMatrix.loc[FinalOrder, FinalOrder]
plt.figure(figsize=(12, 8))
cax = plt.imshow(CorrelationMatrix, cmap='coolwarm', interpolation='none')
plt.colorbar(cax)
plt.xticks(np.arange(len(CorrelationMatrix.columns)), CorrelationMatrix.columns, rotation=90)
plt.yticks(np.arange(len(CorrelationMatrix.columns)), CorrelationMatrix.columns)
for i in range(len(CorrelationMatrix.columns)):
    for j in range(len(CorrelationMatrix.columns)):
        plt.text(j, i, f'{CorrelationMatrix.iloc[i, j]:.2f}', ha='center', va='center', color='black')
plt.title('Correlation Matrix')
plt.show()
#transform test,val data

Ytrain['TaskMachineCombo'] = encoder4.fit_transform(Ytrain['TaskMachineCombo'])
Xtrain=Xtrain.drop(["TaskMachineCombo"], axis=1)


Xval[['LotQuality', 'LotQualityT2']] = encoder1.transform(Xval[['LotQuality', 'LotQualityT2']])
Xval[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']] = scaler.transform(Xval[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']])
Xval['DLWBID'] = encoder2.transform(Xval['DLWBID'])
Xval['DLDBID'] = encoder3.transform(Xval['DLDBID'])
Yval['TaskMachineCombo'] = encoder4.transform(Yval['TaskMachineCombo'])
Xinputs = Xval[['TimeDL', 'LotQualityAverage']]
Xval['DLWBIDApproximation'] = regdw.predict(Xinputs)
# Xval['LotQualityT2Approximation'] = reglq2.predict(Xinputs)
FeaturestoScale = [
    "DLWBIDApproximation",
]
Xval[FeaturestoScale] = scaler2.transform(Xval[FeaturestoScale])
ColumnsDrop = ["TimeWBDL", "TimeDBDL", "LotQuality", "LotQualityT2", "DLWBID", "DLDBID","OwnID","TaskMachineQualityCombo"]
Xval.drop(columns=ColumnsDrop, inplace=True)


Xtest[['LotQuality', 'LotQualityT2']] = encoder1.transform(Xtest[['LotQuality', 'LotQualityT2']])
Xtest[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']] = scaler.transform(Xtest[['TimeWBDL', 'TimeDL', 'TimeDBDL', 'LotQualityAverage']])
Xtest['DLWBID'] = encoder2.transform(Xtest['DLWBID'])
Xtest['DLDBID'] = encoder3.transform(Xtest['DLDBID'])
Ytest['TaskMachineCombo'] = encoder4.transform(Ytest['TaskMachineCombo'])
Xinputs = Xtest[['TimeDL', 'LotQualityAverage']]
Xtest['DLWBIDApproximation'] = regdw.predict(Xinputs)
# Xtest['LotQualityT2Approximation'] = reglq2.predict(Xinputs)
FeaturestoScale = [
    "DLWBIDApproximation",
]

Xtest[FeaturestoScale] = scaler2.transform(Xtest[FeaturestoScale])
ColumnsDrop = ["TimeWBDL", "TimeDBDL", "LotQuality", "LotQualityT2", "DLWBID", "DLDBID", "OwnID","TaskMachineQualityCombo"]
Xtest.drop(columns=ColumnsDrop, inplace=True)
DesiredOrder = ['TimeDL', 'LotQualityAverage','DLWBIDApproximation']
RemainingColumns = [col for col in Xtest.columns if col not in DesiredOrder]
FinalOrder = DesiredOrder + RemainingColumns
Xtest = Xtest[FinalOrder]
Xval=Xval[FinalOrder]

#knn

# ParamGrid = {
#     'n_neighbors': [2,3, 5,6,4, 7, 9, 11,13,15,17,25],
#     'weights': ['uniform', 'distance'],
#     'metric': ['euclidean', 'manhattan','minkowski'],
#     'p': [1, 2],
#     'algorithm': ['auto','ball_tree', 'kd_tree','brute']
# }

# BestScore = -1
# BestParams = None
# BestModel = None

# for n_neighbors in ParamGrid['n_neighbors']:
#     for weights in ParamGrid['weights']:
#         for metric in ParamGrid['metric']:
#             for p in ParamGrid['p']:
#                 for algorithm in ParamGrid['algorithm']:
#                     # Train the model with the current hyperparameters
#                     model = KNeighborsClassifier(
#                         n_neighbors=n_neighbors,
#                         weights=weights,
#                         metric=metric,
#                         p=p,
#                         algorithm=algorithm
#                     )
#                     model.fit(Xtrain, Ytrain)

#                     # Evaluate on the validation set
#                     val_score = model.score(Xval, Yval)

#                     # Check for improvement
#                     if val_score > BestScore:
#                         BestScore = val_score
#                         BestParams = {
#                             'n_neighbors': n_neighbors,
#                             'weights': weights,
#                             'metric': metric,
#                             'p': p,
#                             'algorithm': algorithm
#                         }
#                         BestModel = model
#                         no_improvement_count = 0  
#                     else:
#                         no_improvement_count += 1

#                     # Check if patience is exceeded
#                     if no_improvement_count >= 50:
#                         print("Convergence achieved. Stopping early.")
#                         print("Best Parameters:", BestParams)
#                         print("Best Validation Score:", BestScore)
#                         break
#                 if no_improvement_count >= 50:
#                     break
#             if no_improvement_count >= 50:
#                 break
#         if no_improvement_count >= 50:
#             break
#     if no_improvement_count >= 50:
#         break

# print("Best Hyperparameters:", BestParams)
# print("Best Validation Accuracy:", BestScore)
# YValPred = BestModel.predict(Xval)
# print("\nClassification Report on Validation Set:")
# print(classification_report(Yval, YValPred))
# FinalModel = KNeighborsClassifier(**BestParams)
# print('Training final model...')
# FinalModel.fit(OgXtrain, Ytrain)
# print('Training complete.')
# scaler = StandardScaler()
# OgXtest[['TimeDL', 'LotQualityAverage']] = scaler.fit_transform(OgXtest[['TimeDL', 'LotQualityAverage']])
# YtestPred2 = FinalModel.predict(OgXtest)
# TestAccuracy = accuracy_score(Ytest, YtestPred2)
# print("Test Set Accuracy on OgXtrain Features:", TestAccuracy)
# print(classification_report(Ytest, YtestPred2, zero_division=0))
# YtestPred = BestModel.predict(Xtest)
# TestAccuracy = accuracy_score(Ytest, YtestPred)
# print("Test Set Accuracy:", TestAccuracy)
# print(classification_report(Ytest, YtestPred, zero_division=0))
# BaseKNNModel = KNeighborsClassifier()  # Uses default parameters
# BaseKNNModel.fit(Xtrain, Ytrain)
# YValPredbase = BaseKNNModel.predict(Xval)
# print("Classification Report on Validation Set (Base KNN Model):")
# print(classification_report(Yval, YValPredbase))


#mlp




# ParamGrid = {
#     'hidden_layer_sizes': [
#     (10,10,10,10)],  # Architectures 
#     'activation': ['tanh'],  # Activation functions ,'identity','logistic','tanh'
#     'solver': ['adam'],  # Optimizers , 'sgd',
#     'alpha': [0.00001,0.001,0.0001],  # Regularization parameters 
#     'learning_rate_init': [0.01,0.001,0.1],  # Learning rates 
#     'max_iter': [3000]  # Maximum iterations 
# }
# BestScore = -1
# BestParams = None
# BestModel = None

# for hidden_layer_sizes in ParamGrid['hidden_layer_sizes']:
#     for activation in ParamGrid['activation']:
#         for solver in ParamGrid['solver']:
#             for alpha in ParamGrid['alpha']:
#                 for learning_rate_init in ParamGrid['learning_rate_init']:
#                     for max_iter in ParamGrid['max_iter']:
#                         model = MLPClassifier(
#                             hidden_layer_sizes=hidden_layer_sizes,
#                             activation=activation,
#                             solver=solver,
#                             alpha=alpha,
#                             learning_rate_init=learning_rate_init,
#                             max_iter=max_iter,
#                             random_state=5
#                         )
#                         model.fit(Xtrain, Ytrain)

#                         val_score = model.score(Xval, Yval)

#                         if val_score > BestScore:
#                             BestScore = val_score
#                             BestParams = {
#                                 'hidden_layer_sizes': hidden_layer_sizes,
#                                 'activation': activation,
#                                 'solver': solver,
#                                 'alpha': alpha,
#                                 'learning_rate_init': learning_rate_init,
#                                 'max_iter': max_iter
#                             }
#                             BestModel = model
#                             no_improvement_count = 0  
#                         else:
#                             no_improvement_count += 1

#                         if no_improvement_count >= 50:
#                             print("Convergence achieved. Stopping early.")
#                             print("Best Parameters:", BestParams)
#                             print("Best Validation Score:", BestScore)
#                             break
#                     if no_improvement_count >= 50:
#                         break
#                 if no_improvement_count >= 50:
#                     break
#             if no_improvement_count >= 50:
#                 break
#         if no_improvement_count >= 50:
#             break
#     if no_improvement_count >= 50:
#         break

# print("Best Hyperparameters:", BestParams)
# print("Best Validation Accuracy:", BestScore)
# YValPred = BestModel.predict(Xval)
# print("\nClassification Report on Validation Set:")
# print(classification_report(Yval, YValPred))
# FinalModel = MLPClassifier(**BestParams, random_state=5)
# print('y')
# FinalModel.fit(OgXtrain, Ytrain)
# print('x')
# scaler = StandardScaler()
# OgXtest[['TimeDL','LotQualityAverage']] = scaler.fit_transform(OgXtest[['TimeDL', 'LotQualityAverage']])
# YtestPred2 = FinalModel.predict(OgXtest)
# TestAccuracy = accuracy_score(Ytest, YtestPred2)
# print("Test Set Accuracy on OgXtrain Features:", TestAccuracy)
# print(classification_report(Ytest, YtestPred2, zero_division=0))
# YtestPred = BestModel.predict(Xtest)
# TestAccuracy = accuracy_score(Ytest, YtestPred)
# print("Test Set Accuracy:", TestAccuracy)
# print(classification_report(Ytest, YtestPred, zero_division=0))


#3



# Define a parameter grid for XGBClassifier
ParamGrid = {
    'n_estimators': [100],  # Number of trees 25,50, 100,200,250
    'learning_rate': [0.1],  # Shrinkage step size 0.1,0.001,0.0001,0.00001,0.000001
    'max_depth': [3],  # Maximum depth of a tree , 2,5, 7,8,10
    'colsample_bytree': [0.7],  # Fraction of features used for each tree 0.3,0.5,0.7,0.8,1.0
    'gamma': [0.2],  # Minimum loss reduction for a split  0.2,0,0.1,0.3,0.25 
    'reg_alpha': [ 0.5],  # L1 regularization 0,0.1,0.5,0.7,0.8
    'reg_lambda': [1.5],  # L2 regularization 0,1,1.5,2,2.5
}

BestScore = -1
BestParams = None
BestModel = None

# Manual grid search loop
for n_estimators in ParamGrid['n_estimators']:
    for learning_rate in ParamGrid['learning_rate']:
        for max_depth in ParamGrid['max_depth']:
                for colsample_bytree in ParamGrid['colsample_bytree']:
                    for gamma in ParamGrid['gamma']:
                        for reg_alpha in ParamGrid['reg_alpha']:
                            for reg_lambda in ParamGrid['reg_lambda']:
                                model = XGBClassifier(
                                    n_estimators=n_estimators,
                                    learning_rate=learning_rate,
                                    max_depth=max_depth,
                                    colsample_bytree=colsample_bytree,
                                    gamma=gamma,
                                    reg_alpha=reg_alpha,
                                    reg_lambda=reg_lambda,
                                    eval_metric='logloss'  
                                )
                                model.fit(Xtrain, Ytrain)

                                val_score = model.score(Xval, Yval)
                                if val_score > BestScore:
                                    BestScore = val_score
                                    BestParams = {
                                        'n_estimators': n_estimators,
                                        'learning_rate': learning_rate,
                                        'max_depth': max_depth,
                                        'colsample_bytree': colsample_bytree,
                                        'gamma': gamma,
                                        'reg_alpha': reg_alpha,
                                        'reg_lambda': reg_lambda,
                                    }
                                    BestModel = model

print("Best Hyperparameters:", BestParams)
print("Best Validation Accuracy:", BestScore)
print("Best Hyperparameters:", BestParams)
print("Best Validation Accuracy:", BestScore)
YValPred = BestModel.predict(Xval)
print("\nClassification Report on Validation Set:")
print(classification_report(Yval, YValPred))
FinalModel = XGBClassifier(**BestParams, use_label_encoder=False, eval_metric='logloss')
print('Training final model...')
FinalModel.fit(OgXtrain, Ytrain)
print('Training complete.')
scaler = StandardScaler()
OgXtest[['TimeDL', 'LotQualityAverage']] = scaler.fit_transform(OgXtest[['TimeDL', 'LotQualityAverage']])
YtestPred2 = FinalModel.predict(OgXtest)
TestAccuracy = accuracy_score(Ytest, YtestPred2)
print("Test Set Accuracy on OgXtrain Features:", TestAccuracy)
print(classification_report(Ytest, YtestPred2, zero_division=0))
YtestPred = BestModel.predict(Xtest)
TestAccuracy = accuracy_score(Ytest, YtestPred)
print("Test Set Accuracy:", TestAccuracy)
print(classification_report(Ytest, YtestPred, zero_division=0))
BaseXGBModel = XGBClassifier(use_label_encoder=False, eval_metric='logloss')  # Uses default parameters
BaseXGBModel.fit(Xtrain, Ytrain)
YValPredbase = BaseXGBModel.predict(Xval)
print("Classification Report on Validation Set (Base XGB Model):")
print(classification_report(Yval, YValPredbase))


