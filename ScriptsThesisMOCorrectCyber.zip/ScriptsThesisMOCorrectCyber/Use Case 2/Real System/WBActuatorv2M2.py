#Importing modules
import time
from contextlib import contextmanager
import logging
import random

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data
#Write file function
def WriteFile(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

#Wait for task WBA
def WaitForTaskWBAM2():
    """Waits to be assigned a task from the WireBonder (AvailWBM2 > 0)."""
    print("WBAM2 Actuator Current_Activity: WaitForTaskWBAM2")
    while True:
        AvailWBM2 = ReadFile("AvailWBM2.txt")
        try:
            AvailWBM2 = int(AvailWBM2)
        except ValueError:
            print("Invalid data in AvailWBM2.txt. Waiting for valid data.")
            time.sleep(1)
            continue
        
        if AvailWBM2 == 1:
            WriteFile("AvailWBM2.txt", "0")
            WriteFile("AvailWBAM2.txt", "1")
            PerformWireBonding() #WBA.T2
#Perform wire bonding time varying depending on quality which is assigned based on random percentage
def PerformWireBonding():
    """Performs wire bonding."""
    print("WBAM2 Actuator Current_Activity: Performing wire bonding")
    percentage= random.randint(0,100);  #QualityPercentage
    #80% is good quality 1, 12.5% is decent quality 2, 7.5% is bade quality 3
    if percentage <= 78:
        time.sleep(10)  #WireBondingDurationM2Q1
        quality="1";
        WriteFile("AvailWBAM2.txt", "0")
        WriteFile("QualityM2.txt", quality)
        WaitForTaskWBAM2()

    if percentage >92:
        time.sleep(31) #WireBondingDurationM2Q3
        quality="3";
        WriteFile("AvailWBAM2.txt", "0")
        WriteFile("QualityM2.txt", quality)
        WaitForTaskWBAM2()

    if percentage > 78 and percentage <= 92:
        time.sleep(12.28571428571428) #WireBondingDurationM2Q2
        quality="2";
        WriteFile("AvailWBAM2.txt", "0")
        WriteFile("QualityM2.txt", quality)
        WaitForTaskWBAM2() #WBA.T3

#Call the function
if __name__ == "__main__":
    WaitForTaskWBAM2() #WBA.T1
