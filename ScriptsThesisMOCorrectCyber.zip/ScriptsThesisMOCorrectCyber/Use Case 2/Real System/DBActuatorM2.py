#Importing modules
import time
from contextlib import contextmanager
import logging
import random

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data
#Write file function
def WriteFile(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

def WaitForTaskDBAM2():
    """Waits to be assigned a task from the WireBonder (AvailDBM2 > 0)."""
    print("DBAM2 Actuator Current_Activity: WaitForTaskDBAM2")
    while True:
        AvailDBM2 = ReadFile("AvailDBM2.txt")
        try:
            AvailDBM2 = int(AvailDBM2)
        except ValueError:
            print("Invalid data in AvailDBM2.txt. Waiting for valid data.")
            time.sleep(1)
            continue
        
        if AvailDBM2 == 1:
            WriteFile("AvailDBM2.txt", "0")
            WriteFile("AvailDBAM2.txt", "1")
            PerformDieBonding() #DBA.T2
#Perform diebonding time varying depending on quality which is assigned based on random percentage
def PerformDieBonding():
    """Performs wire bonding."""
    print("DBAM2 Actuator Current_Activity: Performing die bonding")
    percentage= random.randint(0,100);   #QualityPercentage
    #80% is good quality 1, 12.5% is decent quality 2, 7.5% is bad quality 3
    if percentage <= 80:
        time.sleep(15) #WireBondingDurationM2Q1T2
        quality="1";
        WriteFile("AvailDBAM2.txt", "0")
        WriteFile("QualityM2T2.txt", quality)
        WaitForTaskDBAM2()

    if percentage >92.5:
        time.sleep(43.373958850579186) #WireBondingDurationM2Q3T2
        quality="3";
        WriteFile("AvailDBAM2.txt", "0")
        WriteFile("QualityM2T2.txt", quality)
        WaitForTaskDBAM2()

    if percentage > 80 and percentage <= 92.5:
        time.sleep(35.86133897536676) #WireBondingDurationM2Q2T2
        quality="2";
        WriteFile("AvailDBAM2.txt", "0")
        WriteFile("QualityM2T2.txt", quality)
        WaitForTaskDBAM2() #DBA.T3

#Call the function
if __name__ == "__main__":
    WaitForTaskDBAM2() #DBA.T1
