def CalculateTimes(t1, targetavg, targetstd):
    Q1= 0.75;
    Q2=0.15;
    Q3=0.1;

    remainingavg = targetavg - Q1 * t1

    upperlimit = targetavg + targetstd

    t3 = upperlimit - 1  
    
    t2 = (remainingavg - Q3 * t3) / Q2
    
    if t2 >= upperlimit:
        raise ValueError("t2 exceeds the upper limit. Try adjusting Q1 or std.")
    
    # Return the values of t1, t2, and t3
    return t1, t2, t3

# DM2
# t1 = 15          
# targetavg = 19.735714285714284
# targetstd = 24.638244564864905

# #DM1
t1 = 25         
targetavg = 30.805
targetstd = 28.523425557873576


#WB1
# t1 = 10      
# targetavg = 12
# targetstd = 20
try:
    t1, t2, t3 = CalculateTimes(t1, targetavg, targetstd)
    print(f"Calculated values:")
    print(f"Q1 (t1): {t1}")
    print(f"Q2 (t2): {t2}")
    print(f"Q3 (t3): {t3}")
except ValueError as e:
    print(e)

# Given values
Q1 = 85
Q2 = 10
Q3 = 5
t1 = 12
t2 = 33.302155202037014
t3 = 41.46390476425928

