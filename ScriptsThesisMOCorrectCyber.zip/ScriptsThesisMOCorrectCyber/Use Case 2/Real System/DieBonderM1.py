#Importing modules
import time
from contextlib import contextmanager
import logging

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

#Open file function
@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise
#Retry opening file if failed
def RetryOperation(operation, maxretries=10, delay=1):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None

#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None
#Write file function
def WriteFile(filepath, content):
    try:
        with OpenFile(filepath, 'w') as file:
            file.write(content)
    except IOError as e:
        logging.error(f"Error writing to {filepath}: {e}")

def ReadFromFile(filepath):
    return RetryOperation(lambda: ReadFile(filepath))

def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFile(filepath, content))

#Wait for task DB
def WaitForTaskDBM1():
    """Waits to be assigned a task from the DieBonder (AvailDDBM1 > 0)."""
    logging.info("WireBonder Current_Activity: Waiting for task DBM1")
    while True:
        AvailDDBM1 = ReadFromFile("AvailDDBM1.txt")
        if AvailDDBM1 is None:
            logging.error("Failed to read AvailDDBM1.txt. Retrying")
            time.sleep(1)
            continue
        
        if AvailDDBM1 == 1:
            WriteToFile("AvailDDBM1.txt", "0")
            ScheduleTaskDBActuator() #DB.T2
#ScheduleTask DBActuator
def ScheduleTaskDBActuator():
    """Schedules the DBActuator task and updates AvailDBM1"""
    logging.info("WireBonder Current_Activity: Scheduling task DBActuator")
    time.sleep(2) #ScheduleTaskDBActuatorDuration
    WriteToFile("AvailDBM1.txt", "1")
    WaitForTaskDBM1()  #DB.T3
#Call function
if __name__ == "__main__":
    try:
        WaitForTaskDBM1()      #DB.T1
    except Exception as e:
        logging.error(f"An error occurred: {e}")
