#Importing modules
import time
from contextlib import contextmanager
import logging

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise
#Retry opening file if failed
def RetryOperation(operation, maxretries=10, delay=0.6):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}. ")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None
#Read file function
def ReadFile(filepath):
    return RetryOperation(lambda: ReadFileContents(filepath))
#Write file function
def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFileContents(filepath, content))

def ReadFileContents(filepath):
    with OpenFile(filepath, 'r') as file:
        return file.read().strip()

def WriteFileContents(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)
#Monitor die bond environment
def MonitorDieBondEnvironment():
    """Updates AvailDBSM1 based on AvailDBAM1"""
    logging.info("DBSM2 Sensor Current_Activity: Monitor die bond environment")
    while True:
        AvailDBAM2 = RetryOperation(lambda: int(ReadFile("AvailDBAM2.txt")))

        if AvailDBAM2 is None:
            logging.warning("Failed to read AvailDBAM2.txt. Retrying")
            time.sleep(1)
            continue
        
        if AvailDBAM2 == 1:
            WriteToFile("AvailDBSM2.txt", "0")
            logging.info("Set AvailDBSM2.txt to 0")

        elif AvailDBAM2 == 0:
            WriteToFile("AvailDBSM2.txt", "1")
            logging.info("Set AvailDBSM2.txt to 1")
        #DBS.T2
        #DBSensorRestDuration to avoid constant checking
        time.sleep(1)
        #DBS.T3
#Call function
if __name__ == "__main__":
    MonitorDieBondEnvironment() #DBS.T1
