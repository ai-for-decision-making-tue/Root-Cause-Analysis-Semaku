#Importing modules
import socket
from contextlib import contextmanager
import time
import threading
import logging

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

#Open file function
@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise
#Retry opening file if failed
def RetryOperation(operation, maxretries=10, delay=1):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None
#Write file function
def WriteFile(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)

#Read value of AvailWBSM1 
def ReadWBSM1():
    return RetryOperation(lambda: ReadFile("AvailWBSM1.txt"))
#Read value of AvailWBSM2 
def ReadWBSM2():
    return RetryOperation(lambda: ReadFile("AvailWBSM2.txt"))
#Read value of QualityM1
def ReadQM1():
    return RetryOperation(lambda: ReadFile("QualityM1.txt"))
#Read value of QualityM2
def ReadQM2():
    return RetryOperation(lambda: ReadFile("QualityM2.txt"))
#Send AvailWBSM1 and QualityM1 to JadeCommunicator
def SendAvailWBSM1(status,quality):
    try:
        JadeSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        JadeSocket.settimeout(10)
        JadeSocket.connect(('localhost', 54321))
        message = f"AvailWBSM1 status: {status},{quality}\n"
        JadeSocket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailWBSM1 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        JadeSocket.close()
#Send AvailWBSM2 and QualityM2 to JadeCommunicator
def SendAvailWBSM2(status,quality):
    try:
        JadeSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        JadeSocket.settimeout(10)
        JadeSocket.connect(('localhost', 54323))
        message = f"AvailWBSM2 status: {status},{quality}\n"
        JadeSocket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailWBSM2 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        JadeSocket.close()
#Update JC
#Update AvailDWBM1
def UpdateDWBM1(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDWBM1.txt", str(DWBAvail))) 
#Update AvailDWBM2
def UpdateDWBM2(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDWBM2.txt", str(DWBAvail)))
#Receive AvailDWBM1 and AvailDWBM2 updates from JadeCommunicator
def ListenForJadeUpdates():
    ServerSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    ServerSocket.bind(('localhost', 54322))
    ServerSocket.listen(1)  

    logging.info("Listening for JADE agent updates on port 54322")

    while True:
        try:
            ClientSocket, addr = ServerSocket.accept()
            logging.info(f"Connection established with {addr}")

            data = ClientSocket.recv(1024).decode('utf-8').strip()
            logging.info(f"Received data: {data}")

            if data.startswith("Current AvailDWBM1 value: "):
                try:
                    avail_dwbm1 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDWBM1 value: {avail_dwbm1}")
                    UpdateDWBM1(avail_dwbm1)
                except ValueError:
                    logging.error("Error parsing AvailDWBM1 value from the received data.")
            elif data.startswith("Current AvailDWBM2 value: "):
                try:
                    avail_dwbm2 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDWBM2 value: {avail_dwbm2}")
                    UpdateDWBM2(avail_dwbm2)
                except ValueError:
                    logging.error("Error parsing AvailDWBM2 value from the received data.")

            ClientSocket.close()

        except Exception as e:
            logging.error(f"Error in ListenForJadeUpdates: {e}")
#Monitor change value of AvailWBS
def MonitorWBSChange():
    LastAvailWBSM1 = None
    LastAvailWBSM2 = None
    
    while True:
        AvailWBSM1 = ReadWBSM1()
        AvailWBSM2 = ReadWBSM2()
        QM1= ReadQM1()
        QM2=ReadQM2()

        if AvailWBSM1 is not None:
            if LastAvailWBSM1 != AvailWBSM1:
   #             logging.info(f"AvailWBSM1 has changed; new value is: {AvailWBSM1}")
                SendAvailWBSM1(AvailWBSM1,QM1) #PC.T2
                LastAvailWBSM1 = AvailWBSM1
         #   else:
         #       logging.info("No change in AvailWBSM1 value.")

        if AvailWBSM2 is not None:
            if LastAvailWBSM2 != AvailWBSM2:
    #            logging.info(f"AvailWBSM2 has changed; new value is: {AvailWBSM2}")
                SendAvailWBSM2(AvailWBSM2,QM2) #PC.T2
                LastAvailWBSM2 = AvailWBSM2
        #    else:
         #       logging.info("No change in AvailWBSM2 value.")

        time.sleep(2) #Technically this is PC.T3
#Call functions and set up socket thread
if __name__ == "__main__":
    try:
        JadeListener_thread = threading.Thread(target=ListenForJadeUpdates, daemon=True)
        JadeListener_thread.start()
        
        logging.info("Starting MonitorWBSChange")
        MonitorWBSChange() #PC.T1
    except Exception as e:
        logging.error(f"An error occurred: {e}")
