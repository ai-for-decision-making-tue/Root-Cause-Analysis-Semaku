#Importing modules
import subprocess
import os
import time

#List of variables/txt files used in previous runs
Txtfiles= [
    r"C:\RealWireBonderPythonCase2\AvailDWBM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailDWBM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBAM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBAM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBSM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailWBSM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailDDBM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailDDBM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBAM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBAM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBM2.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBSM1.txt",
    r"C:\RealWireBonderPythonCase2\AvailDBSM2.txt"
]

#Function to delete files
def DeleteFiles(files):
    for file in files:
        try:
            if os.path.exists(file):
                os.remove(file)
                print(f"Deleted {file}")
            else:
                print(f"{file} does not exist, skipping.")
        except Exception as e:
            print(f"Error deleting {file}: {e}")

#List of all scripts to open
Scripts = [
    r"C:\RealWireBonderPythonCase2\PythonCommunicatorv2.py",
    r"C:\RealWireBonderPythonCase2\WBActuatorv2.py",
    r"C:\RealWireBonderPythonCase2\WBActuatorv2M2.py",
    r"C:\RealWireBonderPythonCase2\WBSensorv2.py",
    r"C:\RealWireBonderPythonCase2\WBSensorv2M2.py",
    r"C:\RealWireBonderPythonCase2\WireBonderv2.py",
    r"C:\RealWireBonderPythonCase2\WireBonderv2M2.py",
    r"C:\RealWireBonderPythonCase2\PythonCommunicatort2.py",
    r"C:\RealWireBonderPythonCase2\DBActuatorM1.py",
    r"C:\RealWireBonderPythonCase2\DBActuatorM2.py",
    r"C:\RealWireBonderPythonCase2\DBSensorM1.py",
    r"C:\RealWireBonderPythonCase2\DBSensorM2.py",
    r"C:\RealWireBonderPythonCase2\DieBonderM1.py",
    r"C:\RealWireBonderPythonCase2\DieBonderM2.py",      
    r"C:\RealWireBonderPythonCase2\initialize.py"  
]

#Function to run each script in a seperate window
def RunScripts():
    #Delete txtfiles first
    DeleteFiles(Txtfiles)
    
    #First initialize
    InitScript = Scripts.pop()  # Remove the initialization script from the list
    subprocess.Popen(['start', 'cmd', '/k', 'python', InitScript], shell=True)
    
    #Wait for the initialization script to complete
    time.sleep(1)

    #Open each script
    for script in Scripts:
        subprocess.Popen(['start', 'cmd', '/k', 'python', script], shell=True)
#Call the function
if __name__ == "__main__":
    RunScripts()
