#Importing modules
import os
import logging

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
#Initializing AvailWBAM1
def InitializeAvailWBAM1():
    if not os.path.exists("AvailWBAM1.txt"):
        with open("AvailWBAM1.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailWBAM1.txt with AvailWBAM1 = 0.")
#Initializing AvailWBAM2
def InitializeAvailWBAM2():
    if not os.path.exists("AvailWBAM2.txt"):
        with open("AvailWBAM2.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailWBAM2.txt with AvailWBAM2 = 0.")
#Initializing AvailDWBAM1
def InitializeAvailDBAM1():
    if not os.path.exists("AvailDBAM1.txt"):
        with open("AvailDBAM1.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailDBAM1.txt with AvailDBAM1 = 0.")
#Initializing AvailDWBAM2
def InitializeAvailDBAM2():
    if not os.path.exists("AvailDBAM2.txt"):
        with open("AvailDBAM2.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailDBAM2.txt with AvailDBAM2 = 0.")

#Calling the functions
if __name__ == "__main__":
    InitializeAvailWBAM1()
    InitializeAvailWBAM2()
    InitializeAvailDBAM1()
    InitializeAvailDBAM2()
