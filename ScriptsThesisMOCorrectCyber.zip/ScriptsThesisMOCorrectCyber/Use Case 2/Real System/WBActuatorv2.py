#Importing modules
import time
from contextlib import contextmanager
import logging
import random

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data
#Write file function
def WriteFile(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

#Wait for task WBA
def WaitForTaskWBAM1(): 
    """Waits to be assigned a task from the WireBonder (AvailWBM1 > 0)."""
    print("WBAM1 Actuator Current_Activity: WaitForTaskWBAM1") 
    while True:
        AvailWBM1 = ReadFile("AvailWBM1.txt") 
        try:
            AvailWBM1 = int(AvailWBM1)
        except ValueError:
            print("Invalid data in AvailWBM1.txt. Waiting for valid data.")  
            time.sleep(1)
            continue
        
        if AvailWBM1 == 1:
            WriteFile("AvailWBM1.txt", "0")  
            WriteFile("AvailWBAM1.txt", "1")  
            PerformWireBonding() #WBA.T2
#Perform wire bonding time varying depending on quality which is assigned based on random percentage
def PerformWireBonding():
    """Performs wire bonding."""
    print("WBAM1 Actuator Current_Activity: Performing wire bonding")  
    #85% is good quality 1, 10% is decent quality 2, 5% is bad quality 3
    percentage= random.randint(0,100); #QualityPercentage
    if percentage <= 85:
        time.sleep(12)  #WireBondingDurationM1Q1
        quality="1";
        WriteFile("AvailWBAM1.txt", "0") 
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1()  
    if percentage >90:
        time.sleep(33.302155202037014) #WireBondingDurationM1Q2
        quality="2";
        WriteFile("AvailWBAM1.txt", "0")  
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1()  
    if percentage > 85 and percentage <= 90:
        time.sleep(41.46390476425928) #WireBondingDurationM1Q3
        quality="3";
        WriteFile("AvailWBAM1.txt", "0") 
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1() #WBA.T3

#Call the function
if __name__ == "__main__":
    WaitForTaskWBAM1() 
