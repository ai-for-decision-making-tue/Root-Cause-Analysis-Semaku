import random
T1M1Q1=12
T1M1Q2=33.302155202037014
T1M1Q3=41.46390476425928

T1M2Q1=10
T1M2Q2=12.28571428571428
T1M2Q3=31

T2M1Q1=25
T2M1Q2=41.48104962808428
T2M1Q3=58.32842555787357

T2M2Q1=15
T2M2Q2=35.86133897536676
T2M2Q3=43.373958850579186
n=100000000
countx=0;
countt1m1=0;
countt1m2=0;
countt2m1=0;
countt2m2=0;
countt1m1q1=0;
countt1m1q2=0;
countt1m1q3=0;
countt1m2q1=0;
countt1m2q2=0;
countt1m2q3=0;
countt2m1q1=0;
countt2m1q2=0;
countt2m1q3=0;
countt2m2q1=0;
countt2m2q2=0;
countt2m2q3=0;
county=0;
for i in range(100000000):
    percentaget1m= random.randint(0,100);
    percentaget1q= random.randint(0,100);
    percentaget2m= random.randint(0,100);
    percentaget2q= random.randint(0,100);
    
    if percentaget1m <=50:
        t1m=1;
        if percentaget1q <=85:
            t1m1q=1;
            x=12;
        elif percentaget1q >90:
            t1m1q=2;
            x=33.302155202037014
        elif percentaget1q  > 85 and percentaget1q <= 90:
            t1m1q=3;
            x=41.46390476425928 
    elif percentaget1m >50:
        t1m=2
        if percentaget1q <=78:
            t1m2q=1;
            x=10;
        elif percentaget1q  > 78 and percentaget1q <= 92:
            t1m2q=2;
            x=12.28571428571428
        elif percentaget1q >92:
            t1m2q=3;
            x=31
    if percentaget2m <=50:
        t2m=1
        if percentaget2q <=75:
            t2m1q=1;
            y=25;
        elif percentaget2q  > 75 and percentaget2q <= 90:
            t2m1q=2;
            y=41.48104962808428
        elif percentaget2q >90:
            t2m1q=3;
            y=58.32842555787357
    elif percentaget2m >50:
        t2m=2
        if percentaget2q <=80:
            t2m2q=1;
            y=15;
        elif percentaget2q  > 80 and percentaget2q <= 92.5:
            t2m2q=2;
            y=35.86133897536676
        elif percentaget2q >92.5:
            t2m2q=3;
            y=43.373958850579186
    if x >y:
        countx = countx+1
    if y>x:
        county = county+1
    if t1m==1:
        if t1m1q==1:
            if x >y:
                countt1m1q1 = countt1m1q1+1
        if t1m1q==2:
            if x >y:
                countt1m1q2 = countt1m1q2+1
        if t1m1q==3:
            if x >y:
                countt1m1q3 = countt1m1q3+1
        if x >y:
            countt1m1 = countt1m1+1
    if t1m==2:
        if t1m2q==1:
            if x >y:
                countt1m2q1 = countt1m2q1+1
        if t1m2q==2:
            if x >y:
                countt1m2q2 = countt1m2q2+1
        if t1m2q==3:
            if x >y:
                countt1m2q3 = countt1m2q3+1
        if x >y:
            countt1m2 = countt1m2+1
    if t2m==1:
        if t2m1q==1:
            if y >x:
                countt2m1q1 = countt2m1q1+1
        if t2m1q==2:
            if y >x:
                countt2m1q2 = countt2m1q2+1
        if t2m1q==3:
            if y >x:
                countt2m1q3 = countt2m1q3+1
        if y >x:
            countt2m1 = countt2m1+1
    if t2m==2:
        if t2m2q==1:
            if y >x:
                countt2m2q1 = countt2m2q1+1
        if t2m2q==2:
            if y >x:
                countt2m2q2 = countt2m2q2+1
        if t2m2q==3:
            if y >x:
                countt2m2q3 = countt2m2q3+1
        if y >x:
            countt2m2 = countt2m2+1
DT1=countx/n*100
DT2=county/n*100
DT1M1=countt1m1/n*100
DT1M2=countt1m2/n*100
DT2M1=countt2m1/n*100
DT2M2=countt2m2/n*100
DT1M1Q1=countt1m1q1/n*100
DT1M1Q2=countt1m1q2/n*100
DT1M1Q3=countt1m1q3/n*100
DT1M2Q1=countt1m2q1/n*100
DT1M2Q2=countt1m2q2/n*100
DT1M2Q3=countt1m2q3/n*100
DT2M1Q1=countt2m1q1/n*100
DT2M1Q2=countt2m1q2/n*100
DT2M1Q3=countt2m1q3/n*100
DT2M2Q1=countt2m2q1/n*100
DT2M2Q2=countt2m2q2/n*100
DT2M2Q3=countt2m2q3/n*100
total=DT1M1Q1+DT1M1Q2+DT1M1Q3+DT1M2Q1+DT1M2Q2+DT1M2Q3+DT2M1Q1+DT2M1Q2+DT2M1Q3+DT2M2Q1+DT2M2Q2+DT2M2Q3
print("DT1", DT1)
print("DT2", DT2)
print("DT1M1", DT1M1)
print("DT1M2", DT1M2)
print("DT2M1", DT2M1)
print("DT2M2", DT2M2)
print("DT1M1Q1", DT1M1Q1)
print("DT1M1Q2", DT1M1Q2)
print("DT1M1Q3", DT1M1Q3)
print("DT1M2Q1", DT1M2Q1)
print("DT1M2Q2", DT1M2Q2)
print("DT1M2Q3", DT1M2Q3)
print("DT2M1Q1", DT2M1Q1)
print("DT2M1Q2", DT2M1Q2)
print("DT2M1Q3", DT2M1Q3)
print("DT2M2Q1", DT2M2Q1)
print("DT2M2Q2", DT2M2Q2)
print("DT2M2Q3", DT2M2Q3)
print(total)