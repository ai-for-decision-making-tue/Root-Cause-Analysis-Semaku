#Importing modules
import socket
from contextlib import contextmanager
import time
import threading
import logging

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

#Open file function
@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise
#Retry opening file if failed
def RetryOperation(operation, max_retries=10, delay=1):
    for attempt in range(max_retries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None
#Write file function
def WriteFile(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)

#Read value of AvailDBSM1 
def ReadDBSM1():
    return RetryOperation(lambda: ReadFile("AvailDBSM1.txt"))
#Read value of AvailDBSM2 
def ReadDBSM2():
    return RetryOperation(lambda: ReadFile("AvailDBSM2.txt"))
#Read value of QualityM1T2
def ReadQM1T2():
    return RetryOperation(lambda: ReadFile("QualityM1T2.txt"))
#Read value of QualityM2T2
def ReadQM2T2():
    return RetryOperation(lambda: ReadFile("QualityM2T2.txt"))
#Send AvailDBSM1 and QualityM1T2 to JadeCommunicatorT2
def SendAvailDBSM1(status,quality):
    try:
        JadeSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        JadeSocket.settimeout(10)
        JadeSocket.connect(('localhost', 14321))
        message = f"AvailDBSM1 status: {status},{quality}\n"
        JadeSocket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailDBSM1 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        JadeSocket.close()
#Send AvailDBSM2 and QualityM2T2 to JadeCommunicatorT2
def SendAvailDBSM2(status,quality):
    try:
        JadeSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        JadeSocket.settimeout(10)
        JadeSocket.connect(('localhost', 14323))
        message = f"AvailDBSM2 status: {status},{quality}\n"
        JadeSocket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailDBSM2 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        JadeSocket.close()
#Update JC
#Update AvailDDBM1
def UpdateDDBM1(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDDBM1.txt", str(DWBAvail)))
#Update AvailDDBM2
def UpdateDDBM2(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDDBM2.txt", str(DWBAvail)))

def ListenForJadeUpdates():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 14322))
    server_socket.listen(1)

    logging.info("Listening for JADE agent updates on port 54322")

    while True:
        try:
            client_socket, addr = server_socket.accept()
            logging.info(f"Connection established with {addr}")

            data = client_socket.recv(1024).decode('utf-8').strip()
            logging.info(f"Received data: {data}")

            if data.startswith("Current AvailDDBM1 value: "):
                try:
                    avail_DDBM1 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDDBM1 value: {avail_DDBM1}")
                    UpdateDDBM1(avail_DDBM1)
                except ValueError:
                    logging.error("Error parsing AvailDDBM1 value from the received data.")
            elif data.startswith("Current AvailDDBM2 value: "):
                try:
                    avail_DDBM2 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDDBM2 value: {avail_DDBM2}")
                    UpdateDDBM2(avail_DDBM2)
                except ValueError:
                    logging.error("Error parsing AvailDDBM2 value from the received data.")

            client_socket.close()

        except Exception as e:
            logging.error(f"Error in ListenForJadeUpdates: {e}")
#Monitor change value of AvailDBS
def MonitorDBSChange():
    LastAvailDBSM1 = None
    LastAvailDBSM2 = None
    
    while True:
        AvailDBSM1 = ReadDBSM1()
        AvailDBSM2 = ReadDBSM2()
        QM1T2= ReadQM1T2()
        QM2T2=ReadQM2T2()

        if AvailDBSM1 is not None:
            if LastAvailDBSM1 != AvailDBSM1:
   #             logging.info(f"AvailDBSM1 has changed; new value is: {AvailDBSM1}")
                SendAvailDBSM1(AvailDBSM1,QM1T2) #PC.T2
                LastAvailDBSM1 = AvailDBSM1
         #   else:
         #       logging.info("No change in AvailDBSM1 value.")

        if AvailDBSM2 is not None:
            if LastAvailDBSM2 != AvailDBSM2:
    #            logging.info(f"AvailDBSM2 has changed; new value is: {AvailDBSM2}")
                SendAvailDBSM2(AvailDBSM2,QM2T2) #PC.T2
                LastAvailDBSM2 = AvailDBSM2
        #    else:
         #       logging.info("No change in AvailDBSM2 value.")

        time.sleep(2) #Technically this is PC.T3
#Call functions and set up socket thread
if __name__ == "__main__":
    try:
        # Start listening for JADE updates in a separate thread
        JadeListener_thread = threading.Thread(target=ListenForJadeUpdates, daemon=True)
        JadeListener_thread.start()
        
        logging.info("Starting MonitorDBSChange")
        MonitorDBSChange() #PC.T1
    except Exception as e:
        logging.error(f"An error occurred: {e}")
