#Importing modules
import time
from contextlib import contextmanager
import logging
import random

#Logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()
#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data
#Write file function
def WriteFile(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

def WaitForTaskDBAM1():
    """Waits to be assigned a task from the WireBonder (AvailDBM1 > 0)."""
    print("DBAM1 Actuator Current_Activity: WaitForTaskDBAM1") 
    while True:
        AvailDBM1 = ReadFile("AvailDBM1.txt")
        try:
            AvailDBM1 = int(AvailDBM1)
        except ValueError:
            print("Invalid data in AvailDBM1.txt. Waiting for valid data.")  
            time.sleep(1)
            continue
        
        if AvailDBM1 == 1:
            WriteFile("AvailDBM1.txt", "0")  
            WriteFile("AvailDBAM1.txt", "1")  
            PerformDieBonding() #DBA.T2
#Perform diebonding time varying depending on quality which is assigned based on random percentage
def PerformDieBonding():
    """Performs wire bonding."""
    print("DBAM1 Actuator Current_Activity: Performing die bonding") 
    #85% is good quality 1, 10% is decent quality 2, 5% is bad quality 3
    percentage= random.randint(0,100);  #QualityPercentage
    if percentage <= 75:
        time.sleep(25)  #WireBondingDurationM1Q1T2
        quality="1";
        WriteFile("AvailDBAM1.txt", "0")  
        WriteFile("QualityM1T2.txt", quality)
        WaitForTaskDBAM1() 
    if percentage >90:
        time.sleep(58.32842555787357) #WireBondingDurationM1Q3T2
        quality="3";
        WriteFile("AvailDBAM1.txt", "0") 
        WriteFile("QualityM1T2.txt", quality)
        WaitForTaskDBAM1()  
    if percentage > 75 and percentage <= 90:
        time.sleep(41.48104962808428) #WireBondingDurationM1Q2T2
        quality="2";
        WriteFile("AvailDBAM1.txt", "0") 
        WriteFile("QualityM1T2.txt", quality)
        WaitForTaskDBAM1()  #DBA.T3

#Call the function
if __name__ == "__main__":
    WaitForTaskDBAM1() #DBA.T2
