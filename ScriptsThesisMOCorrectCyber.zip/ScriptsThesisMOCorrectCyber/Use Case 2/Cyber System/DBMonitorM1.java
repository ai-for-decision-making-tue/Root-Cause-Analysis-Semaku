import java.util.ArrayList; //import modules
import java.util.List;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

public class DBMonitorM1 extends Agent { 
    private int AvailDBM1 = 0; // initialize attributes
    private int LastAvailDBM1 = 0;
    private int StartTimeDBM1 = 0;
    private int EndTimeDBM1 = 0;
    private int counter = 0;
    private int turnedzero = 0;
    private int TimeDBM1 = 0;
    private int LotQuality=-1; 
    private Set<String> DBM1LIDList;
    private static final String file = "DBM1_variables.txt"; // File to store variables

    @Override
    protected void setup() {
        System.out.println("[DBMonitorM1] " + getLocalName() + " started.");
        DBM1LIDList = new LinkedHashSet<>();

        //Request AvailDBSM1 from CommunicatorT2
        addBehaviour(new TickerBehaviour(this, 500) { // Request every 0.5 seconds
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
                request.setContent("Requesting AvailDBSM1");
                send(request);
            }
        });

        //Request DBIDLIDList from DigitalDB1
        addBehaviour(new TickerBehaviour(this, 500) { // Request every 0.55 seconds
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalDB1", AID.ISLOCALNAME));
                request.setContent("Requesting DBIDLIDList");
                send(request);
            }
        });
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String content = msg.getContent();

                    if (content.startsWith("Current AvailDBSM1 value: ")) {
                        try {
                            String values = (content.split(": ")[1].trim());
                            String availDBSM1 = values.substring(0,1);
                            int AvailDBSM1 = Integer.parseInt(availDBSM1);
                            int QM1 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM1;
                            // Check if AvailDBSM1 equals 1
                            if (AvailDBSM1 == 1) {
                                AvailDBM1 = 1; 
                                if (LastAvailDBM1 == 0) {
                                    StartTimeDBM1 = (int) System.currentTimeMillis();
                                    System.out.println("[DBMonitorM1] " + getLocalName() + " AvailDBM1 updated to: " + AvailDBM1);
                                }
                                if (turnedzero==1) {
                                    EndTimeDBM1 = (int) System.currentTimeMillis();
                                    TimeDBM1 = EndTimeDBM1 - StartTimeDBM1;
                            //        System.out.println("[DBMonitorM1M] " + getLocalName() + " EndTime is " + EndTimeDBM1);

                                    checkAndPerformActions(); 
                                }
                                LastAvailDBM1 = 1;

                                sendAvailDBM1Update();
                            } else if (AvailDBSM1 == 0 && LastAvailDBM1 ==1) {
                                turnedzero=1;
                           //     System.out.println("[DBMonitorM1M] " + getLocalName() + " Updated turnedzero: " + turnedzero);

                                
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[DBMonitorM1] " + getLocalName() + " Error parsing AvailDBSM1 value: " + e.getMessage());
                        }
                    } 
                    
                    else if (content.startsWith("Current DBIDLIDList: ")) {
                        try {
                            String listContent = content.split(": ")[1].trim();
                            if (listContent.startsWith("[") && listContent.endsWith("]")) {
                                listContent = listContent.substring(1, listContent.length() - 1).trim();
                            }

                            String[] items = listContent.split(",");
                            for (String item : items) {
                                String trimmedItem = item.trim();
                                if (trimmedItem.endsWith("1")) {
                                    DBM1LIDList.add(trimmedItem); // Add to the set
                                }
                            }

                        } catch (Exception e) {
                            System.err.println("[DBMonitorM1] Error parsing DBIDLIDList: " + e.getMessage());
                        }
                    } else {
                        System.out.println("[DBMonitorM1] " + getLocalName() + " Received unrecognized message format.");
                    }
                    
                } else {
                    block();
                }
            }
        });
    }

    private void checkAndPerformActions() {
        if (!DBM1LIDList.isEmpty()) {
                turnedzero=0;
                List<String> Lotvariables = new ArrayList<>();
                Lotvariables.add("StartTimeWB1: " + StartTimeDBM1);
                Lotvariables.add("EndTimeDBM1: " + EndTimeDBM1);
                Lotvariables.add("TimeDBM1: " + TimeDBM1);
                Lotvariables.add("DLDBID: " + DBM1LIDList.stream().skip(counter).findFirst()); // Retrieve the first item
                System.out.println("[DBMonitorM1] " + getLocalName() + " Counter: " + counter);
                System.out.println("[DBMonitorM1] " + getLocalName() + "DLDBID: " + DBM1LIDList.stream().skip(counter).findFirst());
                System.out.println("[DBMonitorM1] " + getLocalName() + "DBM1LIDList: " + DBM1LIDList);
                LastAvailDBM1 = 0;
                counter++;
                saveVariablesToFile(Lotvariables);
            
        }
    }
    
    private void saveVariablesToFile(List<String> variables) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write("[DBMonitorM1] " + getLocalName() + " Variables List at " + System.currentTimeMillis() + ":");
            writer.newLine();
            for (String variable : variables) {
                writer.write(variable);
                writer.newLine();
            }
            writer.newLine();
            System.out.println("[DBMonitorM1] " + getLocalName() + " Variables saved to file: " + file);
        } catch (IOException e) {
            System.out.println("[DBMonitorM1] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
        }
    }

    private void sendAvailDBM1Update() {
        try {
            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
            msg.addReceiver(new AID("DigitalDB1", AID.ISLOCALNAME));
            msg.setContent("AvailDBM1 status: " + AvailDBM1);
            send(msg);
        } catch (Exception e) {
            System.out.println("[DBMonitorM1] " + getLocalName() + " Error sending AvailDBM1 update: " + e.getMessage());
        }
    }
}
