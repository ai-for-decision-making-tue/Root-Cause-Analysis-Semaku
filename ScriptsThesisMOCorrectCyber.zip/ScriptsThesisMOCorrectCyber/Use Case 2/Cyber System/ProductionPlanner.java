import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

public class ProductionPlanner extends Agent {
    private int agentCounter = 0; 
    private int interval = 60000; 
    @Override
    protected void setup() {
        System.out.println("[ProductionPlanner] " + getLocalName() + " started.");

        addBehaviour(new TickerBehaviour(this, interval) {
            @Override
            protected void onTick() {
                createAgent("DigitalLot" + agentCounter, "DigitalLot");
                createAgent("LotScheduler" + agentCounter, "LotScheduler");
                createAgent("LotMonitor" + agentCounter, "LotMonitor");
                agentCounter++;
            }
        });
    }

    private void createAgent(String agentName, String agentClassName) {
        try {
            ContainerController container = getContainerController();

            AgentController agentController = container.createNewAgent(agentName, agentClassName, null);
            agentController.start();

            System.out.println("[ProductionPlanner] New agent " + agentName + " of type " + agentClassName + " created and started.");

        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}
