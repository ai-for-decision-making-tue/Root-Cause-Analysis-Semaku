import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.util.ArrayList;
import java.util.List;

public class DigitalLot extends Agent {
    private int AvailDL = 0;
    private int AvailLM = 0;
    private List<Integer> LotOrder;
    private int LotNextStep;
    private boolean StopProcessing = false; 
    private String ConnectedLotScheduler;
    @Override
    protected void setup() {
        System.out.println("[DigitalLot] " + getLocalName() + " started.");

        LotOrder = new ArrayList<>();
        LotOrder.add(1);
        LotOrder.add(2);
        LotOrder.add(3);
        LotNextStep = LotOrder.get(0);

        // Print the initial values
        System.out.println("[DigitalLot] " + getLocalName() + " Initial AvailDL value: " + AvailDL);
        System.out.println("[DigitalLot] " + getLocalName() + " Initial AvailLM value: " + AvailLM);
        System.out.println("[DigitalLot] " + getLocalName() + " Initial LotOrder: " + LotOrder);
        System.out.println("[DigitalLot] " + getLocalName() + " Initial LotNextStep value: " + LotNextStep);
        String agentName = getLocalName();
        int monitorNumber = Integer.parseInt(agentName.replaceAll("\\D+", "")); 
        ConnectedLotScheduler = "LotScheduler" + monitorNumber;
        System.out.println("[DigitalLot] " + getLocalName() + " connected LotScheduler: " + ConnectedLotScheduler);

        
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                if (StopProcessing) {
                    block();
                    return;
                }

                ACLMessage msg = receive();
                if (msg != null) {
          //          System.out.println("[DigitalLot] " + getLocalName() + " Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("AvailLM status: ")) {
                        try {
                            AvailLM = Integer.parseInt(content.split(": ")[1].trim());
                            System.out.println("[DigitalLot] " + getLocalName() + " Received AvailLM value: " + AvailLM);

                            if (AvailLM == 1) {
                                System.out.println("[DigitalLot] " + getLocalName() + " AvailLM updated to: " + AvailLM);

                            } else if (AvailLM == 2) {

                                LotNextStep = LotOrder.get(1);
                                System.out.println("[DigitalLot] " + getLocalName() + " Updated LotNextStep to " + LotNextStep);
                                System.out.println("[DigitalLot] " + getLocalName() + " Updated AvailDL to " + AvailDL);


                            } else if (AvailLM == 3) {         	
                            	AvailDL = 2;
                                System.out.println("[DigitalLot] " + getLocalName() + " AvailLM updated to: " + AvailLM);
                                SendAvailDLUpdate();
                            } 
                            else if (AvailLM == 4) {
                                AvailDL = 3;
                                LotNextStep = LotOrder.get(2);
                                System.out.println("[DigitalLot] " + getLocalName() + " Updated LotNextStep to " + LotNextStep);
                                System.out.println("[DigitalLot] " + getLocalName() + " Updated AvailDL to " + AvailDL);
                                SendAvailDLUpdate();

                            }else if (AvailLM == 5) {
                                StopProcessing = true;
                                System.out.println("[DigitalLot] AvailLM value is 4, stopping further message processing.");
                                doDelete();
                            }


                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalLot] " + getLocalName() + " Error parsing AvailLM value: " + e.getMessage());
                        }
                    } else if (content.equals("Requesting LotNextStep value")) {
                        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
                        reply.addReceiver(msg.getSender());
                        reply.setContent("LotNextStep: " + LotNextStep);
                        send(reply);
          //              System.out.println("[DigitalLot] " + getLocalName() + " Responded with LotNextStep value: " + LotNextStep);
                    }
                } else {
                    block();  
                }


                if (AvailLM == 1 && LotNextStep == 1) {
                    AvailLM = 0;
                    AvailDL = 1;
                    System.out.println("[DigitalLot] " + getLocalName() + " AvailLM updated to: " + AvailLM );
                    System.out.println("[DigitalLot] " + getLocalName() + " AvailDL updated to: " + AvailDL );
                    SendAvailDLUpdate();
                } 
                else {
                    block();
                }
            }
        });
    }

    private void SendAvailDLUpdate() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID(ConnectedLotScheduler, AID.ISLOCALNAME));
        reply.setContent("AvailDL status: " + AvailDL);
        send(reply);
        System.out.println("[DigitalLot] " + getLocalName() + " Message sent to LotScheduler: " + ConnectedLotScheduler +  ": with AvailDL status: " + AvailDL);
    }
}
