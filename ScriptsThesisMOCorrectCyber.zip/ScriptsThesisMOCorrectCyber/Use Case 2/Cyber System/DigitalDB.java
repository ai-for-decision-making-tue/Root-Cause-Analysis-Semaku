import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;  // Import Random class

import jade.core.AID;

public class DigitalDB extends Agent {
    private int AvailDDBM1 = 0;  
    private int AvailDDBM2 = 0; 
    private int AvailDBM1 = 0;
    private int AvailDBM2 = 0;
    private List<String> LotList;
    private List<String> DBIDLIDList;
    private String DigitalLotID;
    private String DBIDLID;
    private String randomnumber;
    private int DBScheduled = 0;
    private static final long serialVersionUID = 1L;

    private Random random = new Random(); 

    @Override
    protected void setup() {
        System.out.println("[DigitalDBv2] " + getLocalName() + " started.");

        // Print the initial values
        System.out.println("[DigitalDBv2] " + getLocalName() + " Initial AvailDDB value: " + AvailDDBM1);
        System.out.println("[DigitalDBv2] " + getLocalName() + " Initial DBScheduled value: " + DBScheduled);
        LotList = new ArrayList<>();
        DBIDLIDList = new ArrayList<>();
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
     //               System.out.println("[DigitalDBv2] " + getLocalName() + " Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("AvailDBM1 status: ")) {
                        try {
                            int availDBM1 = Integer.parseInt(content.split(": ")[1].trim());
            //                System.out.println("[DigitalDBv2] " + getLocalName() + " Received AvailDBM1 value: " + availDBM1);
                            AvailDBM1 = availDBM1;
            //                System.out.println("[DigitalDBv2] " + getLocalName() + " Updated AvailDBM1 value to: " + AvailDBM1);
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalDBv2] " + getLocalName() + " Error parsing AvailDBM value: " + e.getMessage());
                        }
                    }
                    if (content.startsWith("AvailDBM2 status: ")) {
                        try {
                            int availDBM2 = Integer.parseInt(content.split(": ")[1].trim());
            //                System.out.println("[DigitalDBv2] " + getLocalName() + " Received AvailDBM2 value: " + availDBM2);
                            AvailDBM2 = availDBM2;
         //                   System.out.println("[DigitalDBv2] " + getLocalName() + " Updated AvailDBM2 value to: " + AvailDBM2);
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalDBv2] " + getLocalName() + " Error parsing AvailDBM value: " + e.getMessage());
                        }
                    }
                    if (content.equals("Requesting DBIDLIDList")) {
                        ACLMessage reply = msg.createReply();
                        reply.setContent("Current DBIDLIDList: " + DBIDLIDList);
                        send(reply);
                //        System.out.println("[DigitalDBv2] " + getLocalName() + " Responded to DBIDLIDList request with value: " + DBIDLIDList);
                    }

                    if (content.startsWith("AvailLS status: ")) {
                        try {
                            // Split the message on " and LotID: "
                            String[] parts = content.split(" and LotID: ");
                            int AvailLS = Integer.parseInt(parts[0].split("AvailLS status: ")[1].trim());

                            // Extract LotID value
                            String LotID = parts[1].trim();

                            System.out.println("[DigitalDBv2] " + getLocalName() + " Received AvailLS value: " + AvailLS + " and LotID: " + LotID);
                            LotList.add(LotID);
                            System.out.println("[DigitalDBv2] " + getLocalName() + " LotList updated to: " + LotList);
                            if (AvailLS == 1) {
                                DBScheduled = 1;
                                System.out.println("[DigitalDBv2] " + getLocalName() + " DBScheduled updated to: " + DBScheduled);
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalDBv2] " + getLocalName() + " Error parsing AvailLS value: " + e.getMessage());
                        }
                    }

                } else {
                    block();
                }

                if (LotList.size() > 0) {
                    DigitalLotID = LotList.get(0);

                    if (AvailDBM1 == 1 && AvailDBM2 == 1 && DBScheduled == 1) {
                        DBScheduled = 0;


                        // Randomly choose between "1" and "2"
                        randomnumber = (random.nextBoolean() ? "1" : "2");
                        DBIDLID = DigitalLotID + randomnumber;

                        DBIDLIDList.add(DBIDLID);
                        LotList.remove(0);

                        System.out.println("[DigitalDBv2] " + getLocalName() + " DBIDLIDList updated to " + DBIDLIDList);
                        System.out.println("[DigitalDBv2] " + getLocalName() + " randomnumber updated to " + randomnumber);
                        if (randomnumber == "1") {
                        	AvailDBM1=0;
                            AvailDDBM1 = 1;
                            System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM1 updated to " + AvailDDBM1);
                        	SendAvailDDBM1Update();
                        }
                        else if (randomnumber == "2") {
                        	AvailDBM2=0;
                            AvailDDBM2 = 1;
                            System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM2 updated to " + AvailDDBM2);
                        	SendAvailDDBM2Update();
                        }
                    }

                    if (AvailDBM1 == 1 && AvailDBM2 == 0 && DBScheduled == 1) {
                        DBScheduled = 0;
                        AvailDBM1 = 0;
                        AvailDDBM1 = 1;
                        DBIDLID = DigitalLotID + "1";
                        DBIDLIDList.add(DBIDLID);
                        LotList.remove(0);
                        System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM1 updated to " + AvailDDBM1);
                        SendAvailDDBM1Update();
                    }

                    if (AvailDBM1 == 0 && AvailDBM2 == 1 && DBScheduled == 1) {
                        DBScheduled = 0;
                        AvailDBM2 = 0;
                        AvailDDBM2 = 1;
                        DBIDLID = DigitalLotID + "2";
                        DBIDLIDList.add(DBIDLID);
                        LotList.remove(0);
                        System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM2 updated to " + AvailDDBM2);
                        SendAvailDDBM2Update();
                    }
                }
            }
        });
    }

    private void SendAvailDDBM1Update() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
        reply.setContent("AvailDDBM1 updated to: " + AvailDDBM1);
        send(reply);
        System.out.println("[DigitalDBv2] " + getLocalName() + " Message sent to CommunicatorT2 with AvailDDBM1: " + AvailDDBM1);
        AvailDDBM1 = 0;
        System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM1 updated to " + AvailDDBM1);
    }

    private void SendAvailDDBM2Update() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
        reply.setContent("AvailDDBM2 updated to: " + AvailDDBM2);
        send(reply);
        System.out.println("[DigitalDBv2] " + getLocalName() + " Message sent to CommunicatorT2 with AvailDDBM2: " + AvailDDBM2);
        AvailDDBM2 = 0;
        System.out.println("[DigitalDBv2] " + getLocalName() + " AvailDDBM2 updated to " + AvailDDBM2);
    }
}
