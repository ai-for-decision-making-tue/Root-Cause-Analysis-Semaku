import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LotMonitor extends Agent {
    private int AvailLM = 0; 
    private int AvailWBSM1=0;
    private int AvailWBSM2=0;
    private String x;
    private String z;
    private int StartTimeWBDL = 0;
    private int OwnID = -1;
    private String DLWBID;
    private int EndTimeWBDL = 0; 
    private int TimeWBDL = 0; 
    private int LotStarted = 0;
    private int LotNextStep = 0;
    private int previousLotNextStep = -1;
    private List<Integer> LotTaskOrder; 
    private int CreationTimeLM = (int) System.currentTimeMillis();
    private int EndTimeDL=0;
    private int TimeDL = 0;
    private int LastAvailWBSM1 = -1;
    private int FirstAvailWBSM1 = -1;
    private int FirstAvailWBSM2 = -1;
    private int LastAvailWBSM2 = -1;
    private int turnedzero=-1;
    private int LotQuality=0;
    private int LotQualityT2=0;
    private int AvailWBS = 0;
    private int LotStartedT2 = 0;
    private int turnedzeroT2=-1;
    private int AvailDBSM1=0;
    private int AvailDBSM2=0;
    private int StartTimeDBDL = 0;
    private String DLDBID;
    private int EndTimeDBDL = 0; 
    private int TimeDBDL = 0; 
    private int LastAvailDBSM1 = -1;
    private int FirstAvailDBSM1 = -1;
    private int FirstAvailDBSM2 = -1;
    private int LastAvailDBSM2 = -1;
    private int AvailDBS = 0; 

    private final long interval = 500; 
    private static final String file = "agent_variables.txt"; 

    private String ConnectedDigitalLot;


    @Override
    protected void setup() {
        System.out.println("[LotMonitor] " + getLocalName() + " started.");

        String agentName = getLocalName();
        int monitorNumber = Integer.parseInt(agentName.replaceAll("\\D+", "")); 
        
        ConnectedDigitalLot = "DigitalLot" + monitorNumber;

        System.out.println("[LotMonitor] " + getLocalName() + " Connected DigitalLot: " + ConnectedDigitalLot);

        StartTimeWBDL = (int) System.currentTimeMillis();

        LotTaskOrder = new ArrayList<>();

        addBehaviour(new TickerBehaviour(this, interval) {
            @Override
            protected void onTick() {

                ACLMessage requestLotNextStep = new ACLMessage(ACLMessage.REQUEST);
                requestLotNextStep.addReceiver(new AID(ConnectedDigitalLot, AID.ISLOCALNAME));
                requestLotNextStep.setContent("Requesting LotNextStep value");
                send(requestLotNextStep);
           //     System.out.println("[LotMonitor] " + getLocalName() + " Request sent to " + ConnectedDigitalLot + " for LotNextStep value.");

                if (LotStarted==0 && LotNextStep==2) {
                ACLMessage requestAvailWBS = new ACLMessage(ACLMessage.REQUEST);
                requestAvailWBS.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                requestAvailWBS.setContent("Requesting AvailWBS");
                send(requestAvailWBS);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBS.");
            }
                if (LotStarted == 1 && "1".equals(DLWBID)) {
                    ACLMessage requestAvailWBSM1 = new ACLMessage(ACLMessage.REQUEST);
                    requestAvailWBSM1.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                    requestAvailWBSM1.setContent("Requesting AvailWBSM1");
                    send(requestAvailWBSM1);
      //              System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM1.");
                }
                if (LotStarted==1 && "2".equals(DLWBID)) {
                    ACLMessage requestAvailWBSM2 = new ACLMessage(ACLMessage.REQUEST);
                    requestAvailWBSM2.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                    requestAvailWBSM2.setContent("Requesting AvailWBSM2");
                    send(requestAvailWBSM2);
           //         System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM2.");
                }
        }});
        
        addBehaviour(new TickerBehaviour(this, interval) {
            @Override
            protected void onTick() {
                if (LotStartedT2==0) {
                ACLMessage requestAvailDBS = new ACLMessage(ACLMessage.REQUEST);
                requestAvailDBS.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
                requestAvailDBS.setContent("Requesting AvailDBS");
                send(requestAvailDBS);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBS.");
            }
                if (LotStartedT2 == 1 && "1".equals(DLDBID)) {
                    ACLMessage requestAvailDBSM1 = new ACLMessage(ACLMessage.REQUEST);
                    requestAvailDBSM1.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
                    requestAvailDBSM1.setContent("Requesting AvailDBSM1");
                    send(requestAvailDBSM1);
      //              System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM1.");
                }
                if (LotStartedT2==1 && "2".equals(DLDBID)) {
                    ACLMessage requestAvailDBSM2 = new ACLMessage(ACLMessage.REQUEST);
                    requestAvailDBSM2.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
                    requestAvailDBSM2.setContent("Requesting AvailDBSM2");
                    send(requestAvailDBSM2);
           //         System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM2.");
                }
        }});        
        
        
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
                request.setContent("Requesting WBIDLIDList");
                send(request);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Sent request for WBIDLIDList value.");
            }
        });
        
        
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalDB1", AID.ISLOCALNAME));
                request.setContent("Requesting DBIDLIDList");
                send(request);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Sent request for DBIDLIDList value.");
            }
        });

        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
          //          System.out.println("[LotMonitor] " + getLocalName() + " Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("LotNextStep: ")) {
                        try {
                            LotNextStep = Integer.parseInt(content.split(": ")[1].trim());
               //             System.out.println("[LotMonitor] " + getLocalName() + " Updated LotNextStep value: " + LotNextStep);

  
                            if (LotNextStep != previousLotNextStep) {
                                LotTaskOrder.add(LotNextStep);
                                previousLotNextStep = LotNextStep; 
                                System.out.println("[LotMonitor] " + getLocalName() + " LotNextStep added to LotTaskOrder: " + LotTaskOrder);
                            }

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing LotNextStep value: " + e.getMessage());
                        }
                    } else if (content.startsWith("Current AvailWBS value: ")) {
                        try {
                            AvailWBS = Integer.parseInt(content.split(": ")[1].trim());
                     //       System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBS value: " + AvailWBS);

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBS value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current AvailWBSM1 value: ")) {
                        try {
                            String values1 = (content.split(": ")[1].trim());
                            String availWBSM1 = values1.substring(0,1);
                            AvailWBSM1 = Integer.parseInt(availWBSM1);
                            int QM1 = Integer.parseInt(values1.substring(2,3));
                            LotQuality= QM1;
                    //        System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBSM1 value: " + AvailWBSM1);
                            if (FirstAvailWBSM1==1 && AvailWBSM1 ==0) {
                                LastAvailWBSM1=AvailWBSM1;

                            }
                            if (LastAvailWBSM1==0 && AvailWBSM1==1 ) {
                            	turnedzero=1;
                            }
                            FirstAvailWBSM1=AvailWBSM1;

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBSM1 value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current WBIDLIDList: ")) {
                        try {
                        	if (ConnectedDigitalLot.length() < 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,11));
                        	}
                        	else if (ConnectedDigitalLot.length() == 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,12));
                    //			System.out.println("[LotMonitor] " + getLocalName() + " OwnID is " + OwnID);	

                        	}
                        	else if (ConnectedDigitalLot.length() == 13) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,13));
                        	}

                        	String listContent = content.split(": ")[1].trim();
                        	String[] strid = listContent.split("[\\\\,\\\\[DigitalLot\\\\]\\]]");
                        	for (String s : strid) {
                        		x=s.trim();
                       // 		System.out.println("x is" + x);
                        		if (x.startsWith(Integer.toString(OwnID))) {
                        			String xy =x.split("[OwnID]")[0].trim();
                        		//	System.out.println("[LotMonitor] " + getLocalName() + " xy " + xy);	
                        			if(xy.startsWith(Integer.toString(OwnID))){
                        				int z = xy.length();
                        				if (z == 2) {
                        				DLWBID = xy.substring(1,2);
                        			}
                        				else if (z == 3) {
                        					DLWBID = xy.substring(2,3);
                        				}
                        				else if (z==4) {
                        					DLWBID = xy.substring(3,4);
                        				}
                        				}

                        		//	System.out.println("[LotMonitor] " + getLocalName() + " ID is " + DLWBID);	
                        		}
                        	}
                  //      	System.out.println("[LotMonitor] " + getLocalName() + " WBIDLIDList content: " + listContent);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " ConnectedDigitalLot: " + ConnectedDigitalLot);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " Found DLWBID: " + DLWBID);
                          //  System.out.println("[LotMonitor] " + getLocalName() + "yeah");
                        } catch (Exception e) {
                            System.err.println("[LotMonitor] " + getLocalName() + "  Error processing WBIDLIDList: " + e.getMessage());
                        }
                    }


                    
                    else if (content.startsWith("Current AvailWBSM2 value: ")) {
                        try {
                            String values = (content.split(": ")[1].trim());
                            String availWBSM2 = values.substring(0,1);
                            AvailWBSM2 = Integer.parseInt(availWBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM2;
                 //           System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBSM2 value: " + AvailWBSM2);
                            if (FirstAvailWBSM2==1 && AvailWBSM2 ==0) {
                                LastAvailWBSM2=AvailWBSM2;

                            }
                            if (LastAvailWBSM2==0 && AvailWBSM2==1 ) {
                            	turnedzero=1;
                            }
                            FirstAvailWBSM2=AvailWBSM2;

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBSM2 value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current AvailDBS value: ")) {
                        try {
                            AvailDBS = Integer.parseInt(content.split(": ")[1].trim());
                     //       System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailDBS value: " + AvailDBS);

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailDBS value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current AvailDBSM1 value: ")) {
                        try {
                            String values1 = (content.split(": ")[1].trim());
                            String availDBSM1 = values1.substring(0,1);
                            AvailDBSM1 = Integer.parseInt(availDBSM1);
                            int QM1 = Integer.parseInt(values1.substring(2,3));
                            LotQualityT2= QM1;
                    //        System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailDBSM1 value: " + AvailDBSM1);
                            if (FirstAvailDBSM1==1 && AvailDBSM1 ==0) {
                                LastAvailDBSM1=AvailDBSM1;

                            }
                            if (LastAvailDBSM1==0 && AvailDBSM1==1 ) {
                            	turnedzeroT2=1;
                            }
                            FirstAvailDBSM1=AvailDBSM1;

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailDBSM1 value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current DBIDLIDList: ")) {
                        try {
                        	if (ConnectedDigitalLot.length() < 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,11));
                        	}
                        	else if (ConnectedDigitalLot.length() == 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,12));
                    //			System.out.println("[LotMonitor] " + getLocalName() + " OwnID is " + OwnID);	

                        	}
                        	else if (ConnectedDigitalLot.length() == 13) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,13));
                        	}
  
                        	String listContent = content.split(": ")[1].trim();
                        	String[] strid = listContent.split("[\\\\,\\\\[DigitalLot\\\\]\\]]");
                        	for (String s : strid) {
                        		z=s.trim();
                       // 		System.out.println("x is" + x);
                        		if (z.startsWith(Integer.toString(OwnID))) {
                        			String xy =z.split("[OwnID]")[0].trim();
                        		//	System.out.println("[LotMonitor] " + getLocalName() + " xy " + xy);	
                        			if(xy.startsWith(Integer.toString(OwnID))){
                        				int z = xy.length();
                        				if (z == 2) {
                        				DLDBID = xy.substring(1,2);
                        			}
                        				else if (z == 3) {
                        					DLDBID = xy.substring(2,3);
                        				}
                        				else if (z==4) {
                        					DLDBID = xy.substring(3,4);
                        				}
                        				}

                        		//	System.out.println("[LotMonitor] " + getLocalName() + " ID is " + DLDBID);	
                        		}
                        	}
                  //      	System.out.println("[LotMonitor] " + getLocalName() + " DBIDLIDList content: " + listContent);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " ConnectedDigitalLot: " + ConnectedDigitalLot);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " Found DLDBID: " + DLDBID);
                          //  System.out.println("[LotMonitor] " + getLocalName() + "yeah");
                        } catch (Exception e) {
                            System.err.println("[LotMonitor] " + getLocalName() + "  Error processing DBIDLIDList: " + e.getMessage());
                        }
                    }


                    
                    else if (content.startsWith("Current AvailDBSM2 value: ")) {
                        try {
                            String values = (content.split(": ")[1].trim());
                            String availDBSM2 = values.substring(0,1);
                            AvailDBSM2 = Integer.parseInt(availDBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQualityT2= QM2;
                 //           System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailDBSM2 value: " + AvailDBSM2);
                            if (FirstAvailDBSM2==1 && AvailDBSM2 ==0) {
                                LastAvailDBSM2=AvailDBSM2;

                            }
                            if (LastAvailDBSM2==0 && AvailDBSM2==1 ) {
                            	turnedzeroT2=1;
                            }
                            FirstAvailDBSM2=AvailDBSM2;

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailDBSM2 value: " + e.getMessage());
                        }
                    }
                } else {
                    block();  
                }
            }


            private void checkAndPerformActions() {
                if (AvailWBS == 1 && LotStarted == 0 && LotNextStep == 2) {
                	StartTimeWBDL = (int) System.currentTimeMillis();
                    AvailWBS = 0;
                    System.out.println("[LotMonitor] " + getLocalName() + "it actually gets here");
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated StartTimeWBDL value: " + StartTimeWBDL);
                    AvailLM = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                    LotStarted = 1;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                }

                if (turnedzero == 1 && DLWBID.equals("1") && LotStarted == 1) {
                    EndTimeWBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    System.out.println("[LotMonitor] " + getLocalName() + "DLWBID1 here" + DLWBID );
                    TimeWBDL = EndTimeWBDL - StartTimeWBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStarted = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 4;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }
                
                if (turnedzero == 1 && DLWBID.equals("2") && LotStarted == 1) {
                    EndTimeWBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    System.out.println("[LotMonitor] " + getLocalName() + "DLWBID2 here" + DLWBID );
                    TimeWBDL = EndTimeWBDL - StartTimeWBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStarted = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 4;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }

                
                if (AvailDBS == 1 && LotStartedT2 == 0 && LotNextStep == 1) {
                    StartTimeDBDL = (int) System.currentTimeMillis();
                    AvailDBS = 0;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBS value: " + AvailWBS);
                    AvailLM = 1;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                    LotStartedT2 = 1;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                }


                if (turnedzeroT2 == 1 && DLDBID.equals("1") && LotStartedT2 == 1) {
                    EndTimeDBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    TimeDBDL = EndTimeDBDL - StartTimeDBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStartedT2 = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 2;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }
                
                if (turnedzeroT2 == 1 && DLDBID.equals("2") && LotStartedT2 == 1) {
                    EndTimeDBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    TimeDBDL = EndTimeDBDL - StartTimeDBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStartedT2 = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 2;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }
                
                
                
                
                
                
                

                if (LotNextStep == 3) {
                    AvailLM = 5;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    EndTimeDL = (int) System.currentTimeMillis();
                    TimeDL = EndTimeDL - CreationTimeLM;
                    List<String> Lotvariables = new ArrayList<>();
                    Lotvariables.add(OwnID + "," + CreationTimeLM + "," + StartTimeWBDL + ","+ EndTimeWBDL + ","+ EndTimeDL + "," + TimeWBDL + ","+ TimeDL + ","+ DLWBID + ","+ LotQuality + "," + StartTimeDBDL + ","+ EndTimeDBDL + ","+ TimeDBDL + ","+  DLDBID + ","+ LotQualityT2);
                    // Save variables to a file
                    saveVariablesToFile(Lotvariables);
                    sendUpdateToDigitalLot();
                    doDelete();
                }
            }

            private void sendUpdateToDigitalLot() {
                ACLMessage updateMessage = new ACLMessage(ACLMessage.INFORM);
                updateMessage.addReceiver(new AID(ConnectedDigitalLot, AID.ISLOCALNAME));
                updateMessage.setContent("AvailLM status: " + AvailLM);
                send(updateMessage);
                System.out.println("[LotMonitor] " + getLocalName() + " Sent update to " + ConnectedDigitalLot + ": AvailLM updated to: " + AvailLM);
            }


            private void saveVariablesToFile(List<String> variables) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                    writer.newLine();
                    for (String variable : variables) {
                        writer.write(variable);
                        writer.newLine();
                    }
                    writer.newLine();
                    System.out.println("[LotMonitor] " + getLocalName() + " Variables saved to file: " + file);
                } catch (IOException e) {
                    System.out.println("[LotMonitor] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
                }
            }
        });
    }

    @Override
    protected void takeDown() {
        System.out.println("[LotMonitor] " + getLocalName() + " terminating.");
    }
}


