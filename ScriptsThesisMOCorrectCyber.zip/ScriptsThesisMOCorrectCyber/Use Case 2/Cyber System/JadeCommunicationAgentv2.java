//Import modules
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;
//Define agent
public class JadeCommunicationAgentv2 extends Agent {
	//Initialize variables
    private static final long serialVersionUID = 1L;
    private ServerSocket serverSocket1, serverSocket2;
    private ExecutorService threadPool; 
    private BlockingQueue<ACLMessage> messageQueue;
    private int AvailWBS = 0;
    private int AvailWBSM1 = 6;
    private int AvailWBSM2 = 6;
    private int LotQualityM1 = 6;
    private int LotQualityM2 = 6;
    private int PWBM = 0;
    private int counter = 0;

    @Override
    protected void setup() {
        System.out.println("[JadeCommunicationAgentv2] " + getLocalName() + " started.");

        threadPool = Executors.newFixedThreadPool(10);
        messageQueue = new LinkedBlockingQueue<>();

        // Start server socket to listen for connections from Python for AvailWBSM1
        new Thread(() -> {
            try {
                serverSocket1 = new ServerSocket(54321);
                System.out.println("[JadeCommunicationAgentv2] Listening on port 54321");
                while (true) {
                    Socket clientSocket = serverSocket1.accept();
                    new ClientHandler(clientSocket).start();
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentv2] Error in server socket 1: " + e.getMessage());
            }
        }).start();

        // Start server socket to listen for connections from Python for AvailWBSM2
        new Thread(() -> {
            try {
                serverSocket2 = new ServerSocket(54323);
                System.out.println("[JadeCommunicationAgentv2] Listening on port 54323");
                while (true) {
                    Socket clientSocket = serverSocket2.accept();
                    new ClientHandler2(clientSocket).start();
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentv2] Error in server socket 2: " + e.getMessage());
            }
        }).start();


        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    try {
                        messageQueue.put(msg); 
                    } catch (InterruptedException e) {
                        System.out.println("[JadeCommunicationAgentv2] Error adding message to queue: " + e.getMessage());
                    }
                } else {
                    block();
                }
            }
        });

   
        new Thread(() -> {
            while (true) {
                try {
                    ACLMessage msg = messageQueue.take(); 
                    handleMessage(msg); 
                } catch (InterruptedException e) {
                    System.out.println("[JadeCommunicationAgentv2] Message processing interrupted: " + e.getMessage());
                }
            }
        }).start();
    }

    // Method to handle incoming messages
    private void handleMessage(ACLMessage msg) {
        String content = msg.getContent().trim();
    //    System.out.println("[JadeCommunicationAgentv2] Handling message: " + content);

        switch (content) {
            case "Requesting AvailWBS":
                handleAvailWBSRequest(msg);
                break;
            case "Requesting AvailWBSM1":
                sendReply(msg, "Current AvailWBSM1 value: " + AvailWBSM1+","+LotQualityM1);
                break;
            case "Requesting AvailWBSM2":
                sendReply(msg, "Current AvailWBSM2 value: " + AvailWBSM2+","+LotQualityM2);
                break;
            default:
                handleUpdateMessages(content);
                break;
        }
    }

    private void sendReply(ACLMessage msg, String content) {
        ACLMessage reply = msg.createReply();
        reply.setContent(content);
        send(reply);
    //    System.out.println("[JadeCommunicationAgentv2] Responded: " + content);
    }

    private void handleUpdateMessages(String content) {
        if (content.startsWith("AvailDWBM1 updated to: ")) {
            try {
                int availDWBM1 = Integer.parseInt(content.split(": ")[1].trim());
                PWBM = 1;
                sendUpdateToPython(availDWBM1);
            } catch (NumberFormatException e) {
                System.out.println("[JadeCommunicationAgentv2] Error parsing AvailDWBM1 value: " + e.getMessage());
            }
        } else if (content.startsWith("AvailDWBM2 updated to: ")) {
            try {
                int availDWBM2 = Integer.parseInt(content.split(": ")[1].trim());
                PWBM = 2;
                sendUpdateToPython(availDWBM2);
            } catch (NumberFormatException e) {
                System.out.println("[JadeCommunicationAgentv2] Error parsing AvailDWBM2 value: " + e.getMessage());
            }
        } else {
            System.out.println("[JadeCommunicationAgentv2] Unrecognized message content: " + content);
        }
    }

    private void handleAvailWBSRequest(ACLMessage msg) {
        AvailWBS = (counter > 0) ? 1 : 0;
        sendReply(msg, "Current AvailWBS value: " + AvailWBS);
        if (AvailWBS > 0) {
            counter--; 
        }
     //   System.out.println("[JadeCommunicationAgentv2] Responded to AvailWBS request with value: " + AvailWBS);
    }

    @Override
    protected void takeDown() {
        try {
            if (serverSocket1 != null && !serverSocket1.isClosed()) {
                serverSocket1.close();
                System.out.println("[JadeCommunicationAgentv2] Server socket 1 closed.");
            }
            if (serverSocket2 != null && !serverSocket2.isClosed()) {
                serverSocket2.close();
                System.out.println("[JadeCommunicationAgentv2] Server socket 2 closed.");
            }
        } catch (Exception e) {
            System.out.println("[JadeCommunicationAgentv2] Error closing server socket: " + e.getMessage());
        }
        threadPool.shutdown();
        System.out.println("[JadeCommunicationAgentv2] Agent terminating.");
    }

    private void sendUpdateToPython(int availDWBM) {
        try (Socket socket = new Socket("localhost", 54322);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            if (PWBM == 1) {
                out.println("Current AvailDWBM1 value: " + availDWBM);
                System.out.println("[JadeCommunicationAgentv2] Sent update to Python: AvailDWBM1 updated to " + availDWBM);
                PWBM = 0;
            } else if (PWBM == 2) {
                out.println("Current AvailDWBM2 value: " + availDWBM);
                System.out.println("[JadeCommunicationAgentv2] Sent update to Python: AvailDWBM2 updated to " + availDWBM);
                PWBM = 0;
            }
        } catch (Exception e) {
            System.out.println("[JadeCommunicationAgentv2] Error sending update to Python: " + e.getMessage());
        }
    }

    private class ClientHandler extends Thread {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("[JadeCommunicationAgentv2] Received from Python: " + inputLine);
                    if (inputLine.startsWith("AvailWBSM1 status: ")) {
                        try {
                            String values1 = (inputLine.split(": ")[1].trim());
                            System.out.println("[JadeCommunicationAgentv2] aaaaa: " + values1);
                            String availWBSM1 = values1.substring(0,1);
                            AvailWBSM1 = Integer.parseInt(availWBSM1);
                            int QM1 = Integer.parseInt(values1.substring(2,3));
                            LotQualityM1= QM1;
                            counter++; 
                            System.out.println("[JadeCommunicationAgentv2] Updated AvailWBSM1 value: " + AvailWBSM1);
                            System.out.println("[JadeCommunicationAgentv2] Updated LotQualityM1 value: " + LotQualityM1);
                        } catch (NumberFormatException e) {
                            System.out.println("[JadeCommunicationAgentv2] Error parsing AvailWBSM1 value: " + e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentv2] Error handling client socket: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                    System.out.println("[JadeCommunicationAgentv2] Closed client socket.");
                } catch (Exception e) {
                    System.out.println("[JadeCommunicationAgentv2] Error closing client socket: " + e.getMessage());
                }
            }
        }
    }

    private class ClientHandler2 extends Thread {
        private Socket clientSocket;

        public ClientHandler2(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("[JadeCommunicationAgentv2] Received from Python: " + inputLine);
                    if (inputLine.startsWith("AvailWBSM2 status: ")) {
                        try {
                            String values = (inputLine.split(": ")[1].trim());
                            System.out.println("[JadeCommunicationAgentv2] bbbbbb: " + values);
                            String availWBSM2 = values.substring(0,1);
                            AvailWBSM2 = Integer.parseInt(availWBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQualityM2= QM2;
                            counter++; 
                            System.out.println("[JadeCommunicationAgentv2] Updated LotQualityM2 value: " + LotQualityM2);
                            System.out.println("[JadeCommunicationAgentv2] Updated AvailWBSM2 value: " + AvailWBSM2);
                        } catch (NumberFormatException e) {
                            System.out.println("[JadeCommunicationAgentv2] Error parsing AvailWBSM2 value: " + e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentv2] Error handling client socket: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                    System.out.println("[JadeCommunicationAgentv2] Closed client socket.");
                } catch (Exception e) {
                    System.out.println("[JadeCommunicationAgentv2] Error closing client socket: " + e.getMessage());
                }
            }
        }
    }
}
