import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;

public class JadeCommunicationAgentT2 extends Agent {
    private static final long serialVersionUID = 1L;
    private ServerSocket serverSocket1, serverSocket2;
    private ExecutorService threadPool; 
    private BlockingQueue<ACLMessage> messageQueue;
    private int AvailDBS = 0;
    private int AvailDBSM1 = 6;
    private int AvailDBSM2 = 6;
    private int LotQualityM1 = 6;
    private int LotQualityM2 = 6;
    private int PDBM = 0;
    private int counter = 0;

    @Override
    protected void setup() {
        System.out.println("[JadeCommunicationAgentT2] " + getLocalName() + " started.");

        threadPool = Executors.newFixedThreadPool(10);
        messageQueue = new LinkedBlockingQueue<>();

        // Start server socket to listen for connections from Python for AvailDBSM1
        new Thread(() -> {
            try {
                serverSocket1 = new ServerSocket(14321);
                System.out.println("[JadeCommunicationAgentT2] Listening on port 54321");
                while (true) {
                    Socket clientSocket = serverSocket1.accept();
                    new ClientHandler(clientSocket).start();
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentT2] Error in server socket 1: " + e.getMessage());
            }
        }).start();

        // Start server socket to listen for connections from Python for AvailDBSM2
        new Thread(() -> {
            try {
                serverSocket2 = new ServerSocket(14323);
                System.out.println("[JadeCommunicationAgentT2] Listening on port 54323");
                while (true) {
                    Socket clientSocket = serverSocket2.accept();
                    new ClientHandler2(clientSocket).start();
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentT2] Error in server socket 2: " + e.getMessage());
            }
        }).start();

        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    try {
                        messageQueue.put(msg); 
                    } catch (InterruptedException e) {
                        System.out.println("[JadeCommunicationAgentT2] Error adding message to queue: " + e.getMessage());
                    }
                } else {
                    block();
                }
            }
        });

        new Thread(() -> {
            while (true) {
                try {
                    ACLMessage msg = messageQueue.take(); 
                    handleMessage(msg); 
                } catch (InterruptedException e) {
                    System.out.println("[JadeCommunicationAgentT2] Message processing interrupted: " + e.getMessage());
                }
            }
        }).start();
    }

    private void handleMessage(ACLMessage msg) {
        String content = msg.getContent().trim();
    //    System.out.println("[JadeCommunicationAgentT2] Handling message: " + content);

        switch (content) {
            case "Requesting AvailDBS":
                handleAvailDBSRequest(msg);
                break;
            case "Requesting AvailDBSM1":
                sendReply(msg, "Current AvailDBSM1 value: " + AvailDBSM1+","+LotQualityM1);
                break;
            case "Requesting AvailDBSM2":
                sendReply(msg, "Current AvailDBSM2 value: " + AvailDBSM2+","+LotQualityM2);
                break;
            default:
                handleUpdateMessages(content);
                break;
        }
    }

    private void sendReply(ACLMessage msg, String content) {
        ACLMessage reply = msg.createReply();
        reply.setContent(content);
        send(reply);
    //    System.out.println("[JadeCommunicationAgentT2] Responded: " + content);
    }

    private void handleUpdateMessages(String content) {
        if (content.startsWith("AvailDDBM1 updated to: ")) {
            try {
                int availDDBM1 = Integer.parseInt(content.split(": ")[1].trim());
                PDBM = 1;
                sendUpdateToPython(availDDBM1);
            } catch (NumberFormatException e) {
                System.out.println("[JadeCommunicationAgentT2] Error parsing AvailDDBM1 value: " + e.getMessage());
            }
        } else if (content.startsWith("AvailDDBM2 updated to: ")) {
            try {
                int availDDBM2 = Integer.parseInt(content.split(": ")[1].trim());
                PDBM = 2;
                sendUpdateToPython(availDDBM2);
            } catch (NumberFormatException e) {
                System.out.println("[JadeCommunicationAgentT2] Error parsing AvailDDBM2 value: " + e.getMessage());
            }
        } else {
            System.out.println("[JadeCommunicationAgentT2] Unrecognized message content: " + content);
        }
    }

    private void handleAvailDBSRequest(ACLMessage msg) {
        AvailDBS = (counter > 0) ? 1 : 0;
        sendReply(msg, "Current AvailDBS value: " + AvailDBS);
        if (AvailDBS > 0) {
            counter--; 
        }
     //   System.out.println("[JadeCommunicationAgentT2] Responded to AvailDBS request with value: " + AvailDBS);
    }

    @Override
    protected void takeDown() {
        try {
            if (serverSocket1 != null && !serverSocket1.isClosed()) {
                serverSocket1.close();
                System.out.println("[JadeCommunicationAgentT2] Server socket 1 closed.");
            }
            if (serverSocket2 != null && !serverSocket2.isClosed()) {
                serverSocket2.close();
                System.out.println("[JadeCommunicationAgentT2] Server socket 2 closed.");
            }
        } catch (Exception e) {
            System.out.println("[JadeCommunicationAgentT2] Error closing server socket: " + e.getMessage());
        }
        threadPool.shutdown();
        System.out.println("[JadeCommunicationAgentT2] Agent terminating.");
    }

    private void sendUpdateToPython(int availDDBM) {
        try (Socket socket = new Socket("localhost", 14322);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true)) {
            if (PDBM == 1) {
                out.println("Current AvailDDBM1 value: " + availDDBM);
                System.out.println("[JadeCommunicationAgentT2] Sent update to Python: AvailDDBM1 updated to " + availDDBM);
                PDBM = 0;
            } else if (PDBM == 2) {
                out.println("Current AvailDDBM2 value: " + availDDBM);
                System.out.println("[JadeCommunicationAgentT2] Sent update to Python: AvailDDBM2 updated to " + availDDBM);
                PDBM = 0;
            }
        } catch (Exception e) {
            System.out.println("[JadeCommunicationAgentT2] Error sending update to Python: " + e.getMessage());
        }
    }

    private class ClientHandler extends Thread {
        private Socket clientSocket;

        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("[JadeCommunicationAgentT2] Received from Python: " + inputLine);
                    if (inputLine.startsWith("AvailDBSM1 status: ")) {
                        try {
                            String values1 = (inputLine.split(": ")[1].trim());
                            System.out.println("[JadeCommunicationAgentT2] aaaaa: " + values1);
                            String availDBSM1 = values1.substring(0,1);
                            AvailDBSM1 = Integer.parseInt(availDBSM1);
                            int QM1 = Integer.parseInt(values1.substring(2,3));
                            LotQualityM1= QM1;
                            counter++; 
                            System.out.println("[JadeCommunicationAgentT2] Updated AvailDBSM1 value: " + AvailDBSM1);
                            System.out.println("[JadeCommunicationAgentT2] Updated LotQualityM1 value: " + LotQualityM1);
                        } catch (NumberFormatException e) {
                            System.out.println("[JadeCommunicationAgentT2] Error parsing AvailDBSM1 value: " + e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentT2] Error handling client socket: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                    System.out.println("[JadeCommunicationAgentT2] Closed client socket.");
                } catch (Exception e) {
                    System.out.println("[JadeCommunicationAgentT2] Error closing client socket: " + e.getMessage());
                }
            }
        }
    }

    private class ClientHandler2 extends Thread {
        private Socket clientSocket;

        public ClientHandler2(Socket socket) {
            this.clientSocket = socket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    System.out.println("[JadeCommunicationAgentT2] Received from Python: " + inputLine);
                    if (inputLine.startsWith("AvailDBSM2 status: ")) {
                        try {
                            String values = (inputLine.split(": ")[1].trim());
                            System.out.println("[JadeCommunicationAgentT2] bbbbbb: " + values);
                            String availDBSM2 = values.substring(0,1);
                            AvailDBSM2 = Integer.parseInt(availDBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQualityM2= QM2;
                            counter++; 
                            System.out.println("[JadeCommunicationAgentT2] Updated LotQualityM2 value: " + LotQualityM2);
                            System.out.println("[JadeCommunicationAgentT2] Updated AvailDBSM2 value: " + AvailDBSM2);
                        } catch (NumberFormatException e) {
                            System.out.println("[JadeCommunicationAgentT2] Error parsing AvailDBSM2 value: " + e.getMessage());
                        }
                    }
                }
            } catch (Exception e) {
                System.out.println("[JadeCommunicationAgentT2] Error handling client socket: " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                    System.out.println("[JadeCommunicationAgentT2] Closed client socket.");
                } catch (Exception e) {
                    System.out.println("[JadeCommunicationAgentT2] Error closing client socket: " + e.getMessage());
                }
            }
        }
    }
}
