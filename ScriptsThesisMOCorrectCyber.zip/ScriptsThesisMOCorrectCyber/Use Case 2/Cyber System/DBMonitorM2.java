import java.util.ArrayList;
import java.util.List;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

public class DBMonitorM2 extends Agent {
    private int AvailDBM2 = 0; 
    private int LastAvailDBM2 = 0;
    private int StartTimeDBM2 = 0;
    private int EndTimeDBM2 = 0;
    private int counter = 0;
    private int turnedzero=0;
    private int TimeDBM2 = 0;
    private int LotQuality = -1;
    private Set<String> DBM2LIDList;
    private List<String> DBm2variables; 
    private static final String file = "DBm2_variables.txt"; 

    @Override
    protected void setup() {
        System.out.println("[DBMonitorM2] " + getLocalName() + " started.");
        DBm2variables = new ArrayList<>();
        DBM2LIDList = new LinkedHashSet<>();

        // Add behaviour to periodically request the AvailDBM2 value
        addBehaviour(new TickerBehaviour(this, 500) {
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("CommunicatorT2", AID.ISLOCALNAME));
                request.setContent("Requesting AvailDBSM2");
                send(request);
             //   System.out.println("[DBMonitorM2] " + getLocalName() + " Sent request for AvailDBSM2 value.");
            }
        });

        // Add behaviour to periodically request the DBIDLIDList value
        addBehaviour(new TickerBehaviour(this, 500) {
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalDB1", AID.ISLOCALNAME));
                request.setContent("Requesting DBIDLIDList");
                send(request);
         //       System.out.println("[DBMonitorM2] " + getLocalName() + " Sent request for DBIDLIDList value.");
            }
        });

        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String content = msg.getContent();
            //        System.out.println("[DBMonitorM2] " + getLocalName() + " Received message: " + content); // Debug: Print the received message

                    if (content.startsWith("Current AvailDBSM2 value: ")) {
                        try {
                        	
                            String values = (content.split(": ")[1].trim());
                            String availDBSM2 = values.substring(0,1);
                            int AvailDBSM2 = Integer.parseInt(availDBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM2;
            //                System.out.println("[DBMonitorM2] " + getLocalName() + " Received AvailDBSM2 value: " + AvailDBSM2);

                            // Check if AvailDBSM2 equals 1
                            if (AvailDBSM2 == 1) {
                                AvailDBM2 = 1; 
                                if (LastAvailDBM2 == 0) {
                                    StartTimeDBM2 = (int) System.currentTimeMillis();
                                    System.out.println("[DBMonitorM2] " + getLocalName() + " AvailDBM2 updated to: " + AvailDBM2);
                                }
                                if (turnedzero==1) {
                                    EndTimeDBM2 = (int) System.currentTimeMillis();
                                    TimeDBM2 = EndTimeDBM2 - StartTimeDBM2;
                            //        System.out.println("[DBMonitorM2] " + getLocalName() + " EndTime is " + EndTimeDBM2);

                                    checkAndPerformActions(); 
                                }
                                LastAvailDBM2 = 1;
                                

                                sendAvailDBM2Update();
                            } else if (AvailDBSM2 == 0 && LastAvailDBM2 ==1) {
                                
                                turnedzero=1;
                    //            System.out.println("[DBMonitorM2] " + getLocalName() + " Updated turnedzero: " + turnedzero);


                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[DBMonitorM2] " + getLocalName() + " Error parsing AvailDBSM2 value: " + e.getMessage());
                        }
                    } 
                    
                    else if (content.startsWith("Current DBIDLIDList: ")) {
                        try {
                            String listContent = content.split(": ")[1].trim();

                            if (listContent.startsWith("[") && listContent.endsWith("]")) {
                                listContent = listContent.substring(1, listContent.length() - 1).trim();
                            }

                            String[] items = listContent.split(",");
                            for (String item : items) {
                                String trimmedItem = item.trim();
                                if (trimmedItem.endsWith("2")) {
                                    DBM2LIDList.add(trimmedItem); // Add to the set
                                }
                            }

               //             System.out.println("[DBMonitorM2] " + getLocalName() + " Received filtered DBIDLIDList: " + DBM2LIDList);

                        } catch (Exception e) {
                            System.err.println("[DBMonitorM2] Error parsing DBIDLIDList: " + e.getMessage());
                        }
                    } else {
                        System.out.println("[DBMonitorM2] " + getLocalName() + " Received unrecognized message format.");
                    }
                    
                } else {
                    block();
                }
            }
        });
    }

    private void checkAndPerformActions() {
        if (!DBM2LIDList.isEmpty()) {
                turnedzero=0;
                List<String> Lotvariables = new ArrayList<>();
                Lotvariables.add("StartTimeDB2: " + StartTimeDBM2);
                Lotvariables.add("EndTimeDBM2: " + EndTimeDBM2);
                Lotvariables.add("TimeDBM2: " + TimeDBM2);
                Lotvariables.add("DLDBID: " + DBM2LIDList.stream().skip(counter).findFirst()); // Retrieve the first item
                System.out.println("[DBMonitor] " + getLocalName() + " Counter: " + counter);
                System.out.println("[DBMonitor] " + getLocalName() + "DLDBID: " + DBM2LIDList.stream().skip(counter).findFirst());
                System.out.println("[DBMonitor] " + getLocalName() + "DBM1LIDList: " + DBM2LIDList);
                LastAvailDBM2 = 0;
                counter++;
                saveVariablesToFile(Lotvariables);
        }
    }
    
    private void saveVariablesToFile(List<String> variables) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write("[DBMonitor] " + getLocalName() + " Variables List at " + System.currentTimeMillis() + ":");
            writer.newLine();
            for (String variable : variables) {
                writer.write(variable);
                writer.newLine();
            }
            writer.newLine();
            System.out.println("[DBMonitor] " + getLocalName() + " Variables saved to file: " + file);
        } catch (IOException e) {
            System.out.println("[DBMonitor] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
        }
    }

    private void sendAvailDBM2Update() {
        try {
            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
            msg.addReceiver(new AID("DigitalDB1", AID.ISLOCALNAME));
            msg.setContent("AvailDBM2 status: " + AvailDBM2);
            send(msg);
       //     System.out.println("[DBMonitorM2] " + getLocalName() + " Sent AvailDBM2 update to DigitalDB2: " + AvailDBM2);
        } catch (Exception e) {
            System.out.println("[DBMonitorM2] " + getLocalName() + " Error sending AvailDBM2 update: " + e.getMessage());
        }
    }
}
