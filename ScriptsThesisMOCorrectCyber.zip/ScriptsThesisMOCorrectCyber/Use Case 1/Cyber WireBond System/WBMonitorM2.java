import java.util.ArrayList;
import java.util.List;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

public class WBMonitorM2 extends Agent {
    private int AvailWBM2 = 0; 
    private int LastAvailWBM2 = 0;
    private int StartTimeWBM2 = 0;
    private int EndTimeWBM2 = 0;
    private int counter = 0;
    private int turnedzero=0;
    private int TimeWBM2 = 0;
    private int LotQuality = -1;
    private Set<String> WBM2LIDList;
    private List<String> wbm2variables; 
    private static final String file = "wbm2_variables.txt"; 
    @Override
    protected void setup() {
        System.out.println("[WBMonitorM2] " + getLocalName() + " started.");
        wbm2variables = new ArrayList<>();
        WBM2LIDList = new LinkedHashSet<>();

        // Add behaviour to periodically request the AvailWBM2 value
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                request.setContent("Requesting AvailWBSM2");
                send(request);
             //   System.out.println("[WBMonitorM2] " + getLocalName() + " Sent request for AvailWBSM2 value.");
            }
        });

        // Add behaviour to periodically request the WBIDLIDList value
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
                request.setContent("Requesting WBIDLIDList");
                send(request);
         //       System.out.println("[WBMonitorM2] " + getLocalName() + " Sent request for WBIDLIDList value.");
            }
        });


        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String content = msg.getContent();
            //        System.out.println("[WBMonitorM2] " + getLocalName() + " Received message: " + content); // Debug: Print the received message

                    if (content.startsWith("Current AvailWBSM2 value: ")) {
                        try {
                        	
                            String values = (content.split(": ")[1].trim());
                            String availWBSM2 = values.substring(0,1);
                            int AvailWBSM2 = Integer.parseInt(availWBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM2;
            //                System.out.println("[WBMonitorM2] " + getLocalName() + " Received AvailWBSM2 value: " + AvailWBSM2);

                            // Check if AvailWBSM2 equals 1
                            if (AvailWBSM2 == 1) {
                                AvailWBM2 = 1; 
                                if (LastAvailWBM2 == 0) {
                                    StartTimeWBM2 = (int) System.currentTimeMillis();
                                    System.out.println("[WBMonitorM2] " + getLocalName() + " AvailWBM2 updated to: " + AvailWBM2);
                                }
                                if (turnedzero==1) {
                                    EndTimeWBM2 = (int) System.currentTimeMillis();
                                    TimeWBM2 = EndTimeWBM2 - StartTimeWBM2;
                            //        System.out.println("[WBMonitorM2] " + getLocalName() + " EndTime is " + EndTimeWBM2);

                                    checkAndPerformActions(); 
                                }
                                LastAvailWBM2 = 1;
                                

                                sendAvailWBM2Update();
                            } else if (AvailWBSM2 == 0) {
                                AvailWBM2 = 0;
                                
                                turnedzero=1;
                    //            System.out.println("[WBMonitorM2] " + getLocalName() + " Updated turnedzero: " + turnedzero);


                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[WBMonitorM2] " + getLocalName() + " Error parsing AvailWBSM2 value: " + e.getMessage());
                        }
                    } 
                    
                    else if (content.startsWith("Current WBIDLIDList: ")) {
                        try {
                            String listContent = content.split(": ")[1].trim();

                            if (listContent.startsWith("[") && listContent.endsWith("]")) {
                                listContent = listContent.substring(1, listContent.length() - 1).trim();
                            }

                            String[] items = listContent.split(",");
                            for (String item : items) {
                                String trimmedItem = item.trim();
                                if (trimmedItem.endsWith("2")) {
                                    WBM2LIDList.add(trimmedItem); 
                                }
                            }

               //             System.out.println("[WBMonitorM2] " + getLocalName() + " Received filtered WBIDLIDList: " + WBM2LIDList);

                        } catch (Exception e) {
                            System.err.println("[WBMonitorM2] Error parsing WBIDLIDList: " + e.getMessage());
                        }
                    } else {
                        System.out.println("[WBMonitorM2] " + getLocalName() + " Received unrecognized message format.");
                    }
                    
                } else {
                    block();
                }
            }
        });
    }

    private void checkAndPerformActions() {
        if (!WBM2LIDList.isEmpty()) {
                turnedzero=0;
                List<String> Lotvariables = new ArrayList<>();
                Lotvariables.add("StartTimeWB2: " + StartTimeWBM2);
                Lotvariables.add("EndTimeWBM2: " + EndTimeWBM2);
                Lotvariables.add("TimeWBM2: " + TimeWBM2);
                Lotvariables.add("DLWBID: " + WBM2LIDList.stream().skip(counter).findFirst()); // Retrieve the first item
                System.out.println("[WBMonitor] " + getLocalName() + " Counter: " + counter);
                System.out.println("[WBMonitor] " + getLocalName() + "DLWBID: " + WBM2LIDList.stream().skip(counter).findFirst());
                System.out.println("[WBMonitor] " + getLocalName() + "WBM1LIDList: " + WBM2LIDList);
                LastAvailWBM2 = 0;
                StartTimeWBM2 = (int) System.currentTimeMillis();
                counter++;
                saveVariablesToFile(Lotvariables);
        }
    }
    
    private void saveVariablesToFile(List<String> variables) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write("[WBMonitor] " + getLocalName() + " Variables List at " + System.currentTimeMillis() + ":");
            writer.newLine();
            for (String variable : variables) {
                writer.write(variable);
                writer.newLine();
            }
            writer.newLine();
            System.out.println("[WBMonitor] " + getLocalName() + " Variables saved to file: " + file);
        } catch (IOException e) {
            System.out.println("[WBMonitor] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
        }
    }

    private void sendAvailWBM2Update() {
        try {
            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
            msg.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
            msg.setContent("AvailWBM2 status: " + AvailWBM2);
            send(msg);
       //     System.out.println("[WBMonitorM2] " + getLocalName() + " Sent AvailWBM2 update to DigitalWB2: " + AvailWBM2);
        } catch (Exception e) {
            System.out.println("[WBMonitorM2] " + getLocalName() + " Error sending AvailWBM2 update: " + e.getMessage());
        }
    }
}
