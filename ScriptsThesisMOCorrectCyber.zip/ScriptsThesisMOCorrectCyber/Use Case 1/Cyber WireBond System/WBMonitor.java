import java.util.ArrayList;
import java.util.List;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;

public class WBMonitor extends Agent {
    private int AvailWBM1 = 0; 
    private int LastAvailWBM1 = 0;
    private int StartTimeWBM1 = 0;
    private int EndTimeWBM1 = 0;
    private int counter = 0;
    private int turnedzero = 0;
    private int TimeWBM1 = 0;
    private int LotQuality=-1;
    private Set<String> WBM1LIDList;
    private static final String file = "wbm1_variables.txt"; 

    @Override
    protected void setup() {
        System.out.println("[WBMonitor] " + getLocalName() + " started.");
        WBM1LIDList = new LinkedHashSet<>();

        // Add behaviour to periodically request the AvailWBM1 value
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                request.setContent("Requesting AvailWBSM1");
                send(request);
            }
        });

        // Add behaviour to periodically request the WBIDLIDList value
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
                request.setContent("Requesting WBIDLIDList");
                send(request);
            }
        });

        // Add behaviour to handle responses
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
                    String content = msg.getContent();

                    if (content.startsWith("Current AvailWBSM1 value: ")) {
                        try {
                            String values = (content.split(": ")[1].trim());
                            String availWBSM1 = values.substring(0,1);
                            int AvailWBSM1 = Integer.parseInt(availWBSM1);
                            int QM1 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM1;
                            // Check if AvailWBSM1 equals 1
                            if (AvailWBSM1 == 1) {
                                AvailWBM1 = 1; 
                                if (LastAvailWBM1 == 0) {
                                    StartTimeWBM1 = (int) System.currentTimeMillis();
                                    System.out.println("[WBMonitor] " + getLocalName() + " AvailWBM1 updated to: " + AvailWBM1);
                                }
                                if (turnedzero==1) {
                                    EndTimeWBM1 = (int) System.currentTimeMillis();
                                    TimeWBM1 = EndTimeWBM1 - StartTimeWBM1;
                            //        System.out.println("[WBMonitorM] " + getLocalName() + " EndTime is " + EndTimeWBM1);

                                    checkAndPerformActions(); 
                                }
                                LastAvailWBM1 = 1;

                                sendAvailWBM1Update();
                            } else if (AvailWBSM1 == 0) {
                                AvailWBM1 = 0;
                                turnedzero=1;
                           //     System.out.println("[WBMonitorM] " + getLocalName() + " Updated turnedzero: " + turnedzero);

                                
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[WBMonitor] " + getLocalName() + " Error parsing AvailWBSM1 value: " + e.getMessage());
                        }
                    } 
                    
                    else if (content.startsWith("Current WBIDLIDList: ")) {
                        try {
                            String listContent = content.split(": ")[1].trim();


                            if (listContent.startsWith("[") && listContent.endsWith("]")) {
                                listContent = listContent.substring(1, listContent.length() - 1).trim();
                            }

                            String[] items = listContent.split(",");
                            for (String item : items) {
                                String trimmedItem = item.trim();
                                if (trimmedItem.endsWith("1")) {
                                    WBM1LIDList.add(trimmedItem); 
                                }
                            }

                        } catch (Exception e) {
                            System.err.println("[WBMonitor] Error parsing WBIDLIDList: " + e.getMessage());
                        }
                    } else {
                        System.out.println("[WBMonitor] " + getLocalName() + " Received unrecognized message format.");
                    }
                    
                } else {
                    block();
                }
            }
        });
    }

    private void checkAndPerformActions() {
        if (!WBM1LIDList.isEmpty()) {
                turnedzero=0;
                List<String> Lotvariables = new ArrayList<>();
                Lotvariables.add("StartTimeWB1: " + StartTimeWBM1);
                Lotvariables.add("EndTimeWBM1: " + EndTimeWBM1);
                Lotvariables.add("TimeWBM1: " + TimeWBM1);
                Lotvariables.add("DLWBID: " + WBM1LIDList.stream().skip(counter).findFirst()); // Retrieve the first item
                System.out.println("[WBMonitor] " + getLocalName() + " Counter: " + counter);
                System.out.println("[WBMonitor] " + getLocalName() + "DLWBID: " + WBM1LIDList.stream().skip(counter).findFirst());
                System.out.println("[WBMonitor] " + getLocalName() + "WBM1LIDList: " + WBM1LIDList);
                LastAvailWBM1 = 0;
                StartTimeWBM1 = (int) System.currentTimeMillis();
                counter++;
                saveVariablesToFile(Lotvariables);
            
        }
    }
    
    private void saveVariablesToFile(List<String> variables) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write("[WBMonitor] " + getLocalName() + " Variables List at " + System.currentTimeMillis() + ":");
            writer.newLine();
            for (String variable : variables) {
                writer.write(variable);
                writer.newLine();
            }
            writer.newLine();
            System.out.println("[WBMonitor] " + getLocalName() + " Variables saved to file: " + file);
        } catch (IOException e) {
            System.out.println("[WBMonitor] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
        }
    }

    private void sendAvailWBM1Update() {
        try {
            ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
            msg.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
            msg.setContent("AvailWBM1 status: " + AvailWBM1);
            send(msg);
        } catch (Exception e) {
            System.out.println("[WBMonitor] " + getLocalName() + " Error sending AvailWBM1 update: " + e.getMessage());
        }
    }
}
