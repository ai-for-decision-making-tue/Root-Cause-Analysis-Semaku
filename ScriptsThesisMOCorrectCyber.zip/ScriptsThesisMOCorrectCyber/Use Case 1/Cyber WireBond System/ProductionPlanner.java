import jade.core.Agent;
import jade.core.behaviours.TickerBehaviour;
import jade.wrapper.AgentController;
import jade.wrapper.ContainerController;
import jade.wrapper.StaleProxyException;

public class ProductionPlanner extends Agent {
    private int AgentCounter = 0; 
    private int RequestInterval = 6000; 
    @Override
    protected void setup() {
        System.out.println("[ProductionPlanner] " + getLocalName() + " started.");

        addBehaviour(new TickerBehaviour(this, RequestInterval) {
            @Override
            protected void onTick() {
                // Create a new DigitalLot, LotScheduler, and LotMonitor agent every x seconds
                createAgent("DigitalLot" + AgentCounter, "DigitalLot");
                createAgent("LotScheduler" + AgentCounter, "LotScheduler");
                createAgent("LotMonitor" + AgentCounter, "LotMonitor");
                AgentCounter++;
            }
        });
    }

    private void createAgent(String agentName, String agentClassName) {
        try {
            ContainerController container = getContainerController();

            AgentController agentController = container.createNewAgent(agentName, agentClassName, null);
            agentController.start();

            System.out.println("[ProductionPlanner] New agent " + agentName + " of type " + agentClassName + " created and started.");

        } catch (StaleProxyException e) {
            e.printStackTrace();
        }
    }
}
