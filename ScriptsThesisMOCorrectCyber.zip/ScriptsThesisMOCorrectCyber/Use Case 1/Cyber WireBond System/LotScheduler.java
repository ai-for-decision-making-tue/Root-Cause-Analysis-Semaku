import java.util.ArrayList;
import java.util.List;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

public class LotScheduler extends Agent {
    private int AvailLS = 0;
    private boolean StopProcessing = false; 
    private String LotID;

    @Override
    protected void setup() {
        System.out.println("[LotScheduler] " + getLocalName() + " started.");

        // Print the initial values
        System.out.println("[LotScheduler] Initial AvailLS value: " + AvailLS);
        String agentName = getLocalName();
        int monitorNumber = Integer.parseInt(agentName.replaceAll("\\D+", "")); 
        LotID = "DigitalLot" + monitorNumber;
        System.out.println("[LotScheduler] " + getLocalName() + " Lot ID: " + LotID);
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                if (StopProcessing) {
                    block();
                    return;
                }

                ACLMessage msg = receive();
                if (msg != null) {
                    System.out.println("[LotScheduler] Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("AvailDL status: ")) {
                        try {
                            int AvailDL = Integer.parseInt(content.split(": ")[1].trim());
                            System.out.println("[LotScheduler] Updated AvailDL value: " + AvailDL);

                            if (AvailDL == 1) {
                                AvailLS = 1;
                                System.out.println("[LotScheduler] Updated AvailLS value: " + AvailLS);
                                SendAvailLSUpdate();
                            } 
                            else if (AvailDL == 2)  {
                            	StopProcessing = true;
                                System.out.println("[LotScheduler] AvailDL value is 2, stopping further message processing.");
                                doDelete();
                            }

                        } catch (NumberFormatException e) {
                            System.out.println("[LotScheduler] Error parsing AvailDL value: " + e.getMessage());
                        }
                    }
                } else {
                    block();
                }
            }
        });
    }

    private void SendAvailLSUpdate() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
        reply.setContent("AvailLS status: " + AvailLS + " and LotID: " + LotID); 
        send(reply);
        System.out.println("[LotScheduler] Message sent to DigitalWB with AvailLS status: " + AvailLS + " and LotID: " + LotID);
        AvailLS = 0;
        System.out.println("[LotScheduler] Updated AvailLS value: " + AvailLS);
    }
}


