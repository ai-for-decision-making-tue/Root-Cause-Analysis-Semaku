import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.lang.acl.ACLMessage;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;  // Import Random class

import jade.core.AID;

public class DigitalWBv2 extends Agent {
    private int AvailDWBM1 = 0; 
    private int AvailDWBM2 = 0; 
    private int AvailWBM1 = 0;
    private int AvailWBM2 = 0;
    private List<String> LotList;
    private List<String> WBIDLIDList;
    private String DigitalLotID;
    private String WBIDLID;
    private String randomnumber;
    private int WBScheduled = 0;
    private static final long serialVersionUID = 1L;

    private Random random = new Random(); 

    @Override
    protected void setup() {
        System.out.println("[DigitalWBv2] " + getLocalName() + " started.");

        // Print the initial values
        System.out.println("[DigitalWBv2] " + getLocalName() + " Initial AvailDWB value: " + AvailDWBM1);
        System.out.println("[DigitalWBv2] " + getLocalName() + " Initial WBScheduled value: " + WBScheduled);
        LotList = new ArrayList<>();
        WBIDLIDList = new ArrayList<>();
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
     //               System.out.println("[DigitalWBv2] " + getLocalName() + " Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("AvailWBM1 status: ")) {
                        try {
                            int availWBM1 = Integer.parseInt(content.split(": ")[1].trim());
            //                System.out.println("[DigitalWBv2] " + getLocalName() + " Received AvailWBM1 value: " + availWBM1);
                            AvailWBM1 = availWBM1;
            //                System.out.println("[DigitalWBv2] " + getLocalName() + " Updated AvailWBM1 value to: " + AvailWBM1);
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalWBv2] " + getLocalName() + " Error parsing AvailWBM value: " + e.getMessage());
                        }
                    }
                    if (content.startsWith("AvailWBM2 status: ")) {
                        try {
                            int availWBM2 = Integer.parseInt(content.split(": ")[1].trim());
            //                System.out.println("[DigitalWBv2] " + getLocalName() + " Received AvailWBM2 value: " + availWBM2);
                            AvailWBM2 = availWBM2;
         //                   System.out.println("[DigitalWBv2] " + getLocalName() + " Updated AvailWBM2 value to: " + AvailWBM2);
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalWBv2] " + getLocalName() + " Error parsing AvailWBM value: " + e.getMessage());
                        }
                    }
                    if (content.equals("Requesting WBIDLIDList")) {
                        ACLMessage reply = msg.createReply();
                        reply.setContent("Current WBIDLIDList: " + WBIDLIDList);
                        send(reply);
                //        System.out.println("[DigitalWBv2] " + getLocalName() + " Responded to WBIDLIDList request with value: " + WBIDLIDList);
                    }

                    if (content.startsWith("AvailLS status: ")) {
                        try {
                            // Split the message on " and LotID: "
                            String[] parts = content.split(" and LotID: ");
                            int AvailLS = Integer.parseInt(parts[0].split("AvailLS status: ")[1].trim());

                            String LotID = parts[1].trim();

                            System.out.println("[DigitalWBv2] " + getLocalName() + " Received AvailLS value: " + AvailLS + " and LotID: " + LotID);
                            LotList.add(LotID);
                            System.out.println("[DigitalWBv2] " + getLocalName() + " LotList updated to: " + LotList);
                            if (AvailLS == 1) {
                                WBScheduled = 1;
                                System.out.println("[DigitalWBv2] " + getLocalName() + " WBScheduled updated to: " + WBScheduled);
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("[DigitalWBv2] " + getLocalName() + " Error parsing AvailLS value: " + e.getMessage());
                        }
                    }

                } else {
                    block();
                }

                if (LotList.size() > 0) {
                    DigitalLotID = LotList.get(0);

                    if (AvailWBM1 == 1 && AvailWBM2 == 1 && WBScheduled == 1) {
                        WBScheduled = 0;


                        // Randomly choose between "1" and "2"
                        randomnumber = (random.nextBoolean() ? "1" : "2");
                        WBIDLID = DigitalLotID + randomnumber;

                        WBIDLIDList.add(WBIDLID);
                        LotList.remove(0);

                        System.out.println("[DigitalWBv2] " + getLocalName() + " WBIDLIDList updated to " + WBIDLIDList);
                        System.out.println("[DigitalWBv2] " + getLocalName() + " randomnumber updated to " + randomnumber);
                        if (randomnumber == "1") {
                        	AvailWBM1=0;
                            AvailDWBM1 = 1;
                            System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM1 updated to " + AvailDWBM1);
                        	SendAvailDWBM1Update();
                        }
                        else if (randomnumber == "2") {
                        	AvailWBM2=0;
                            AvailDWBM2 = 1;
                            System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM2 updated to " + AvailDWBM2);
                        	SendAvailDWBM2Update();
                        }
                    }

                    if (AvailWBM1 == 1 && AvailWBM2 == 0 && WBScheduled == 1) {
                        WBScheduled = 0;
                        AvailWBM1 = 0;
                        AvailDWBM1 = 1;
                        WBIDLID = DigitalLotID + "1";
                        WBIDLIDList.add(WBIDLID);
                        LotList.remove(0);
                        System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM1 updated to " + AvailDWBM1);
                        SendAvailDWBM1Update();
                    }

                    if (AvailWBM1 == 0 && AvailWBM2 == 1 && WBScheduled == 1) {
                        WBScheduled = 0;
                        AvailWBM2 = 0;
                        AvailDWBM2 = 1;
                        WBIDLID = DigitalLotID + "2";
                        WBIDLIDList.add(WBIDLID);
                        LotList.remove(0);
                        System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM2 updated to " + AvailDWBM2);
                        SendAvailDWBM2Update();
                    }
                }
            }
        });
    }

    private void SendAvailDWBM1Update() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
        reply.setContent("AvailDWBM1 updated to: " + AvailDWBM1);
        send(reply);
        System.out.println("[DigitalWBv2] " + getLocalName() + " Message sent to Communicator with AvailDWBM1: " + AvailDWBM1);
        AvailDWBM1 = 0;
        System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM1 updated to " + AvailDWBM1);
    }

    private void SendAvailDWBM2Update() {
        ACLMessage reply = new ACLMessage(ACLMessage.INFORM);
        reply.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
        reply.setContent("AvailDWBM2 updated to: " + AvailDWBM2);
        send(reply);
        System.out.println("[DigitalWBv2] " + getLocalName() + " Message sent to Communicator with AvailDWBM2: " + AvailDWBM2);
        AvailDWBM2 = 0;
        System.out.println("[DigitalWBv2] " + getLocalName() + " AvailDWBM2 updated to " + AvailDWBM2);
    }
}
