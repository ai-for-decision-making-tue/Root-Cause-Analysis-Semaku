import jade.core.Agent;
import jade.core.behaviours.CyclicBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;
import jade.core.AID;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class LotMonitor extends Agent {
    private int AvailLM = 0; 
    private int AvailWBSM1=0;
    private int AvailWBSM2=0;
    private String x;
    private int StartTimeWBDL = 0;
    private int OwnID = -1;
    private String DLWBID;
    private int EndTimeWBDL = 0; 
    private int TimeWBDL = 0; 
    private int LotStarted = 0; 
    private int LotNextStep = 0;
    private int previousLotNextStep = -1; 
    private List<Integer> LotTaskOrder; 
    private int CreationTimeLM = (int) System.currentTimeMillis();
    private int EndTimeDL=0;
    private int TimeDL = 0;
    private int LastAvailWBSM1 = -1;
    private int FirstAvailWBSM1 = -1;
    private int FirstAvailWBSM2 = -1;
    private int LastAvailWBSM2 = -1;
    private int turnedzero=-1;
    private int LotQuality=0;
    private int AvailWBS = 0; 
    private final long RequestInterval = 500; 
    private static final String file = "agent_variables.txt"; 
    private String ConnectedDigitalLot;


    @Override
    protected void setup() {
        System.out.println("[LotMonitor] " + getLocalName() + " started.");
        String agentName = getLocalName();
        int monitorNumber = Integer.parseInt(agentName.replaceAll("\\D+", "")); 
        ConnectedDigitalLot = "DigitalLot" + monitorNumber;
        System.out.println("[LotMonitor] " + getLocalName() + " Connected DigitalLot: " + ConnectedDigitalLot);
        StartTimeWBDL = (int) System.currentTimeMillis();
        LotTaskOrder = new ArrayList<>();
        addBehaviour(new TickerBehaviour(this, RequestInterval) {
            @Override
            protected void onTick() {
                ACLMessage RequestLotNextStep = new ACLMessage(ACLMessage.REQUEST);
                RequestLotNextStep.addReceiver(new AID(ConnectedDigitalLot, AID.ISLOCALNAME));
                RequestLotNextStep.setContent("Requesting LotNextStep value");
                send(RequestLotNextStep);
           //     System.out.println("[LotMonitor] " + getLocalName() + " Request sent to " + ConnectedDigitalLot + " for LotNextStep value.");

                if (LotStarted==0) {
                ACLMessage RequestAvailWBS = new ACLMessage(ACLMessage.REQUEST);
                RequestAvailWBS.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                RequestAvailWBS.setContent("Requesting AvailWBS");
                send(RequestAvailWBS);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBS.");
            }
                if (LotStarted == 1 && "1".equals(DLWBID)) {
                    ACLMessage RequestAvailWBSM1 = new ACLMessage(ACLMessage.REQUEST);
                    RequestAvailWBSM1.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                    RequestAvailWBSM1.setContent("Requesting AvailWBSM1");
                    send(RequestAvailWBSM1);
      //              System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM1.");
                }
                if (LotStarted==1 && "2".equals(DLWBID)) {
                    ACLMessage RequestAvailWBSM2 = new ACLMessage(ACLMessage.REQUEST);
                    RequestAvailWBSM2.addReceiver(new AID("Communicator", AID.ISLOCALNAME));
                    RequestAvailWBSM2.setContent("Requesting AvailWBSM2");
                    send(RequestAvailWBSM2);
           //         System.out.println("[LotMonitor] " + getLocalName() + " Request sent to JadeCommunicationAgent for AvailWBSM2.");
                }
        }});
        addBehaviour(new TickerBehaviour(this, 500) { 
            @Override
            protected void onTick() {
                ACLMessage request = new ACLMessage(ACLMessage.REQUEST);
                request.addReceiver(new AID("DigitalWB1", AID.ISLOCALNAME));
                request.setContent("Requesting WBIDLIDList");
                send(request);
    //            System.out.println("[LotMonitor] " + getLocalName() + " Sent request for WBIDLIDList value.");
            }
        });
        addBehaviour(new CyclicBehaviour(this) {
            @Override
            public void action() {
                ACLMessage msg = receive();
                if (msg != null) {
          //          System.out.println("[LotMonitor] " + getLocalName() + " Received ACL message from " + msg.getSender().getLocalName() + ": " + msg.getContent());

                    String content = msg.getContent();
                    if (content.startsWith("LotNextStep: ")) {
                        try {
                            LotNextStep = Integer.parseInt(content.split(": ")[1].trim());
               //             System.out.println("[LotMonitor] " + getLocalName() + " Updated LotNextStep value: " + LotNextStep);

                            // Only add the new LotNextStep to the LotTaskOrder list if it differs from the previous step
                            if (LotNextStep != previousLotNextStep) {
                                LotTaskOrder.add(LotNextStep);
                                previousLotNextStep = LotNextStep; 
                                System.out.println("[LotMonitor] " + getLocalName() + " LotNextStep added to LotTaskOrder: " + LotTaskOrder);
                            }

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing LotNextStep value: " + e.getMessage());
                        }
                    } else if (content.startsWith("Current AvailWBS value: ")) {
                        try {
                            AvailWBS = Integer.parseInt(content.split(": ")[1].trim());
                     //       System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBS value: " + AvailWBS);

                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBS value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current AvailWBSM1 value: ")) {
                        try {
                            String values1 = (content.split(": ")[1].trim());
                            String availWBSM1 = values1.substring(0,1);
                            AvailWBSM1 = Integer.parseInt(availWBSM1);
                            int QM1 = Integer.parseInt(values1.substring(2,3));
                            LotQuality= QM1;
                    //        System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBSM1 value: " + AvailWBSM1);
                            if (FirstAvailWBSM1==1 && AvailWBSM1 ==0) {
                                LastAvailWBSM1=AvailWBSM1;

                            }
                            if (LastAvailWBSM1==0 && AvailWBSM1==1 ) {
                            	turnedzero=1;
                            }
                            FirstAvailWBSM1=AvailWBSM1;
                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBSM1 value: " + e.getMessage());
                        }
                    }
                    else if (content.startsWith("Current WBIDLIDList: ")) {
                        try {
                        	if (ConnectedDigitalLot.length() < 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,11));
                        	}
                        	else if (ConnectedDigitalLot.length() == 12) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,12));
                    //			System.out.println("[LotMonitor] " + getLocalName() + " OwnID is " + OwnID);	

                        	}
                        	else if (ConnectedDigitalLot.length() == 13) {
                        		OwnID = Integer.parseInt(ConnectedDigitalLot.substring(10,13));
                        	}
                            
                        	String listContent = content.split(": ")[1].trim();
                        	String[] strid = listContent.split("[\\\\,\\\\[DigitalLot\\\\]\\]]");
                        	for (String s : strid) {
                        		x=s.trim();
                       // 		System.out.println("x is" + x);
                        		if (x.startsWith(Integer.toString(OwnID))) {
                        			String xy =x.split("[OwnID]")[0].trim();
                        		//	System.out.println("[LotMonitor] " + getLocalName() + " xy " + xy);	
                        			if(xy.startsWith(Integer.toString(OwnID))){
                        				int z = xy.length();
                        				if (z == 2) {
                        				DLWBID = xy.substring(1,2);
                        			}
                        				else if (z == 3) {
                        					DLWBID = xy.substring(2,3);
                        				}
                        				else if (z==4) {
                        					DLWBID = xy.substring(3,4);
                        				}
                        				}

                        		//	System.out.println("[LotMonitor] " + getLocalName() + " ID is " + DLWBID);	
                        		}
                        	}
                  //      	System.out.println("[LotMonitor] " + getLocalName() + " WBIDLIDList content: " + listContent);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " ConnectedDigitalLot: " + ConnectedDigitalLot);
                 //       	System.out.println("[LotMonitor] " + getLocalName() + " Found DLWBID: " + DLWBID);
                          //  System.out.println("[LotMonitor] " + getLocalName() + "yeah");
                        } catch (Exception e) {
                            System.err.println("[LotMonitor] " + getLocalName() + "  Error processing WBIDLIDList: " + e.getMessage());
                        }
                    }


                    
                    else if (content.startsWith("Current AvailWBSM2 value: ")) {
                        try {
                            String values = (content.split(": ")[1].trim());
                            String availWBSM2 = values.substring(0,1);
                            AvailWBSM2 = Integer.parseInt(availWBSM2);
                            int QM2 = Integer.parseInt(values.substring(2,3));
                            LotQuality= QM2;
                 //           System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBSM2 value: " + AvailWBSM2);
                            if (FirstAvailWBSM2==1 && AvailWBSM2 ==0) {
                                LastAvailWBSM2=AvailWBSM2;

                            }
                            if (LastAvailWBSM2==0 && AvailWBSM2==1 ) {
                            	turnedzero=1;
                            }
                            FirstAvailWBSM2=AvailWBSM2;
                            checkAndPerformActions();

                        } catch (NumberFormatException e) {
                            System.out.println("[LotMonitor] " + getLocalName() + " Error parsing AvailWBSM2 value: " + e.getMessage());
                        }
                    }
                } else {
                    block();  
                }
            }
            private void checkAndPerformActions() {
                if (AvailWBS == 1 && LotStarted == 0 && LotNextStep == 1) {
                    AvailWBS = 0;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailWBS value: " + AvailWBS);
                    AvailLM = 1;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                    LotStarted = 1;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                }
                if (turnedzero == 1 && DLWBID.equals("1") && LotStarted == 1) {
                    EndTimeWBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    TimeWBDL = EndTimeWBDL - StartTimeWBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStarted = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 2;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }
                
                if (turnedzero == 1 && DLWBID.equals("2") && LotStarted == 1) {
                    EndTimeWBDL = (int) System.currentTimeMillis();
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated EndTimeWBDL value: " + EndTimeWBDL);
                    TimeWBDL = EndTimeWBDL - StartTimeWBDL;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated TimeWBDL value: " + TimeWBDL);
                    LotStarted = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated LotStarted value: " + LotStarted);
                    AvailLM = 2;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    sendUpdateToDigitalLot();
                }
                if (LotNextStep == 2) {
                    AvailLM = 3;
                    System.out.println("[LotMonitor] " + getLocalName() + " Updated AvailLM value: " + AvailLM);
                    EndTimeDL = (int) System.currentTimeMillis();
                    TimeDL = EndTimeDL - CreationTimeLM;
                    List<String> Lotvariables = new ArrayList<>();
                    Lotvariables.add(OwnID + "," + CreationTimeLM + "," + StartTimeWBDL + ","+ EndTimeWBDL + ","+ EndTimeDL + "," + TimeWBDL + ","+ TimeDL + ","+ DLWBID + ","+ LotQuality);
                    // Save variables to a file
                    saveVariablesToFile(Lotvariables);
                    sendUpdateToDigitalLot();
                    doDelete();
                }
            }

            private void sendUpdateToDigitalLot() {
                ACLMessage updateMessage = new ACLMessage(ACLMessage.INFORM);
                updateMessage.addReceiver(new AID(ConnectedDigitalLot, AID.ISLOCALNAME));
                updateMessage.setContent("AvailLM status: " + AvailLM);
                send(updateMessage);
                System.out.println("[LotMonitor] " + getLocalName() + " Sent update to " + ConnectedDigitalLot + ": AvailLM updated to: " + AvailLM);
            }


            private void saveVariablesToFile(List<String> variables) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                    writer.newLine();
                    for (String variable : variables) {
                        writer.write(variable);
                        writer.newLine();
                    }
                    writer.newLine();
                    System.out.println("[LotMonitor] " + getLocalName() + " Variables saved to file: " + file);
                } catch (IOException e) {
                    System.out.println("[LotMonitor] " + getLocalName() + " Error saving variables to file: " + e.getMessage());
                }
            }
        });
    }

    @Override
    protected void takeDown() {
        System.out.println("[LotMonitor] " + getLocalName() + " terminating.");
    }
}


