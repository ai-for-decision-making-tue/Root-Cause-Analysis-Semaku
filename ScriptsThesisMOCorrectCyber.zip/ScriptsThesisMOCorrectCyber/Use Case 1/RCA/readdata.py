import numpy as np
from collections import Counter
import pandas as pd
import statistics as st
import matplotlib.pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import OrdinalEncoder
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import OneHotEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
df = pd.read_csv(r'C:\Users\20172671\Downloads\case1\case1\agent_variablesf.txt', engine='python')
print(df)
#print(df.to_numpy(dtype=str))
OwnID =df["OwnID"]
CreationTimeLM=df["CreationTimeLM"]
StartTimeWBDL=df["StartTimeWBDL"]
EndTimeWBDL=df["EndTimeWBDL"]
EndTimeDL=df["EndTimeDL"]
TimeWBDL=df["TimeWBDL"]
TimeDL=df["TimeDL"]
DLWBID=df["DLWBID"]
LotQuality=df["LotQuality"]
#print(OwnID)
OwnIDArray=OwnID.to_numpy(dtype=str)
OwnIDInt = list(map(int, OwnIDArray))
#print(OwnIDInt)
LotQualityArray=LotQuality.to_numpy(dtype=str)
LotQualityInt = list(map(int, LotQualityArray))
print(LotQualityInt)
TimeWBDLArray=TimeWBDL.to_numpy(dtype=str)
TimeWBDLInt = list(map(int, TimeWBDLArray))
TimeDLArray=TimeDL.to_numpy(dtype=str)
TimeDLInt = list(map(int, TimeDLArray))
print(TimeWBDLInt)

#print(CreationTimeLM)
#print(StartTimeWBDL)
#print(EndTimeWBDL)
#print(EndTimeDL)
#print(TimeWBDL)
#print(TimeDL)
#print(DLWBID)
DLWBIDArray=DLWBID.to_numpy(dtype=str)
DLWBIDInt = list(map(int, DLWBIDArray))
print(DLWBIDInt)
#print(LotQuality)



Machine1=DLWBIDInt
Machine2=LotQualityInt
Machine3=[]
MachineCombo=[]
for i in range(len(Machine1)):
    combined_value = str(Machine1[i]) + str(Machine2[i])
    Machine3.append(combined_value)

Machine3 = list(map(int, Machine3))
#print("Machine3:", Machine3)

#11 =1, 12= 2, 13= 3, 21= 4, 22=5, 23=6

for i in Machine3:
    if i==11:
        MachineCombo.append(1);
    elif i==12:
        MachineCombo.append(2)
    elif i==13:
        MachineCombo.append(3)
    elif i==21:
        MachineCombo.append(4)
    elif i==22:
        MachineCombo.append(5)
    elif i==23:
        MachineCombo.append(6)
ComboCounts = Counter(MachineCombo)
TotalCount = len(MachineCombo)

for combo, count in ComboCounts.items():
    percentage = (count / TotalCount) * 100
    likelihood = count / TotalCount
AvgTimeDL=st.mean(TimeDLInt)
StdTimeDL=st.stdev(TimeDLInt)
print("Avg TimeDL:")
print(AvgTimeDL)
print("Std TimeDL:")
print(StdTimeDL)
AvgTimeWBDL=st.mean(TimeWBDLInt)
StdTimeWBDL=st.stdev(TimeWBDLInt)
print("Avg TimeWBDL:")
print(AvgTimeWBDL)
print("Std TimeWBDL:")
print(StdTimeWBDL)
LotQualityCounts = pd.Series(LotQualityInt).value_counts(normalize=True) * 100
print("Percentage of LotQuality (1, 2, 3):")
print(LotQualityCounts)
DLWBIDCounts = pd.Series(DLWBIDInt).value_counts(normalize=True) * 100
print("\nPercentage of (DLWBIDInt) (1, 2):")
print(DLWBIDCounts)

data = {
    'TimeDL': TimeDLInt,
    'LotQuality': LotQualityInt,
    'DLWBID': DLWBIDInt,
}
df2 = pd.DataFrame(data)
TrainData = df2.drop(["DLWBID"], axis=1)
TargetData = df2[["DLWBID"]]
Xtrain, Xtest, Ytrain, Ytest = train_test_split(TrainData, TargetData, test_size=0.2, random_state=1)
scaler = StandardScaler()
encoder = OrdinalEncoder()
LabelEncoder = LabelEncoder()
Xtrain['TimeDL'] = scaler.fit_transform(Xtrain[['TimeDL']]).flatten()
Xtrain['LotQuality'] = encoder.fit_transform(Xtrain[['LotQuality']]).flatten()
Ytrain['DLWBID'] = LabelEncoder.fit_transform(Ytrain['DLWBID'])
Xtest['TimeDL'] = scaler.transform(Xtest[['TimeDL']]).flatten()
Xtest['LotQuality'] = encoder.transform(Xtest[['LotQuality']]).flatten()
Ytest['DLWBID'] = LabelEncoder.transform(Ytest['DLWBID'])
knn = KNeighborsClassifier(n_neighbors=4)
knn.fit(Xtrain, Ytrain)
Ypred=knn.predict(Xtest)
accuracy = accuracy_score(Ytest, Ypred)
print(f"Accuracy: {accuracy:.2f}", accuracy)
print("\nClassification Report:")
print(classification_report(Ytest, Ypred))
Ypred=knn.predict(Xtrain)
accuracy = accuracy_score(Ytrain, Ypred)
print(f"Accuracy: {accuracy:.2f}", accuracy)
print("\nClassification Report:")
print(classification_report(Ytrain, Ypred))


Machine = Ytrain['DLWBID'].to_numpy().astype(int)
x = Xtrain['TimeDL'].to_numpy()
y = Xtrain['LotQuality'].to_numpy()
yp= y+1
UniqueMachines = np.unique(Machine)
colors = [plt.cm.viridis(i / len(UniqueMachines)) for i in range(len(UniqueMachines))]
for i, machine_id in enumerate(UniqueMachines):
    indices = [j for j in range(len(x)) if Machine[j] == machine_id]
    plt.scatter(
        [x[j] for j in indices],
        [yp[j] for j in indices],
        c=[colors[i]], label=f'Machine {machine_id}'
    )

plt.xlabel('Standardised TimeWBDL')
plt.ylabel('Lot Quality')
plt.title('KNN Prediction of which Machine the Lot was located on')
plt.legend(title="Machine ID", bbox_to_anchor=(1.05, 1), loc='upper left')

print("Machine:", Machine)

RCATimeDL = 23074
RCAQuality = -1+ 2


RCATimeDL = scaler.transform(np.array([[RCATimeDL]]))[0, 0]
RCAPoint = np.array([[RCATimeDL, RCAQuality]])

prediction = knn.predict(RCAPoint)
predicted_machine_index = np.where(UniqueMachines == prediction[0])[0][0]
predicted_machine_color = colors[predicted_machine_index]
plt.scatter(RCATimeDL, RCAQuality+1, c=[predicted_machine_color], edgecolor='black', s=100)
plt.annotate(
    f"RCAPoint, Machine: {prediction[0]}",
    xy=(RCATimeDL, RCAQuality+1),
    xytext=(RCATimeDL + 0.5, RCAQuality + 0.5 +1),
    fontsize=8,
    arrowprops=dict(facecolor='black', shrink=0.05)
)

plt.show()