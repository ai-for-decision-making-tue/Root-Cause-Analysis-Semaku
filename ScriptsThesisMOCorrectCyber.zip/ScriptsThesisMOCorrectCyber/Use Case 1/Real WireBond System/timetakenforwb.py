import pandas as pd
import random
import numpy as np
import statistics as st
import matplotlib.pyplot as plt
import scipy
from scipy import stats
from datetime import datetime
import operator
df = pd.read_excel(r'C:\RealWireBonderPython\BE1MES-AT_GTP_Data_from_SIT_20210907.xlsx')
df = df.loc[:, ~df.columns.str.contains('^productDesc')]
df = df.loc[:, ~df.columns.str.contains('^plantName')]
df = df.loc[:, ~df.columns.str.contains('^txnDateGmt')]
df = df.loc[:, ~df.columns.str.contains('^lotId')]
df = df.loc[:, ~df.columns.str.contains('^product12NC')]
df = df.loc[:, ~df.columns.str.contains('^productTypeName')]
df = df.loc[:, ~df.columns.str.contains('^workflowName')]
df = df.loc[:, ~df.columns.str.contains('^toSpecName')]
df = df.loc[:, ~df.columns.str.contains('^fromObjectCategory')]
df = df.loc[:, ~df.columns.str.contains('^toObjectCategory')]
df = df.loc[:, ~df.columns.str.contains('^employeeName')]
df = df.loc[:, ~df.columns.str.contains('^qty')]
df = df.loc[:, ~df.columns.str.contains('^phaseName')]
df = df.loc[:, ~df.columns.str.contains('^qty2')]
import operator
def ProcessGroup(df, spec_name=None, equipment_name=None, cdo_name=None):
    if spec_name:
        df_group = df[df.specName == spec_name]
    elif equipment_name:
        df_group = df[df.equipmentName == equipment_name]
    elif cdo_name:
        df_group = df[df.cdoName == cdo_name]
    else:
        df_group = df

    wbin_group = df_group[df_group.cdoName == "TrackInLot"]
    wbout_group = df_group[df_group.cdoName == "TrackOutLot"]
    
    # Extract the txnDate and calculate the time differences
    Timewbin = wbin_group["txnDate"]
    Timewbout = wbout_group["txnDate"]
    
    Timein = list(map(lambda x: x[11:19], Timewbin))
    Timeout = list(map(lambda x: x[11:19], Timewbout))

    Timeinhr = list(map(lambda x: x[11:13], Timewbin))
    Timeouthr = list(map(lambda x: x[11:13], Timewbout))
    Timeininthr = list(map(int, Timeinhr))
    Timeoutinthr = list(map(int, Timeouthr))
    Timehr = list(map(operator.sub, Timeoutinthr, Timeininthr))

    Timeinmin = list(map(lambda x: x[14:16], Timewbin))
    Timeoutmin = list(map(lambda x: x[14:16], Timewbout))
    Timeinintmin = list(map(int, Timeinmin))
    Timeoutintmin = list(map(int, Timeoutmin))
    Timemin = list(map(operator.sub, Timeoutintmin, Timeinintmin))

    Timeinsec = list(map(lambda x: x[17:19], Timewbin))
    Timeoutsec = list(map(lambda x: x[17:19], Timewbout))
    Timeinintsec = list(map(int, Timeinsec))
    Timeoutintsec = list(map(int, Timeoutsec))
    Timesec = list(map(operator.sub, Timeoutintsec, Timeinintsec))

    # Convert to total seconds
    x = len(Timehr)
    hr = [60 * 60] * x
    mi = [60] * x
    Timehrsec = list(map(operator.mul, Timehr, hr))
    Timeminsec = list(map(operator.mul, Timemin, mi))
    Timehrmin = list(map(operator.add, Timehrsec, Timeminsec))
    Time = list(map(operator.add, Timehrmin, Timesec))

    # Filter the time to keep only values between 0 and 3000 seconds
    Timelist = []
    for i in Time:
        if i > 0 and i < 3000:
            Timelist.append(i/20)

    return Timelist


# Process each group
Timelist_wb = ProcessGroup(df, spec_name="WIREBOND")
Timelist_db = ProcessGroup(df, spec_name="DIEBOND")
Timelist_M1 = ProcessGroup(df, equipment_name="RFWBHK70")
Timelist_M2 = ProcessGroup(df, equipment_name="LDWBC130")
Timelist_M3 = ProcessGroup(df, equipment_name="LDWBC085")
Timelist_DM1 = ProcessGroup(df, equipment_name="LDDBD_01")
Timelist_DM2 = ProcessGroup(df, equipment_name="LDDBM017")
Timelist_DM3 = ProcessGroup(df, equipment_name="LDDBM018")

# Print the lists for each group
# Wirebond Time
print("Wirebond Timelist:", Timelist_wb)
print("Wirebond Mean:", st.mean(Timelist_wb))
print("Wirebond Std Dev:", st.stdev(Timelist_wb))

# Diebond Time
print("\nDiebond Timelist:", Timelist_db)
print("Diebond Mean:", st.mean(Timelist_db))
print("Diebond Std Dev:", st.stdev(Timelist_db))

# Machine 1 Time
print("\nM1 Timelist:", Timelist_M1)
print("M1 Mean:", st.mean(Timelist_M1))
print("M1 Std Dev:", st.stdev(Timelist_M1))

# Machine 2 Time
print("\nM2 Timelist:", Timelist_M2)
print("M2 Mean:", st.mean(Timelist_M2))
# print("M2 Std Dev:", st.stdev(Timelist_M2))

# Machine 3 Time
print("\nM3 Timelist:", Timelist_M3)
print("M3 Mean:", st.mean(Timelist_M3))
# print("M3 Std Dev:", st.stdev(Timelist_M3))

# Die Machine 1 Time
print("\nDM1 Timelist:", Timelist_DM1)
print("DM1 Mean:", st.mean(Timelist_DM1))
print("DM1 Std Dev:", st.stdev(Timelist_DM1))

# Die Machine 2 Time
print("\nDM2 Timelist:", Timelist_DM2)
print("DM2 Mean:", st.mean(Timelist_DM2))
print("DM2 Std Dev:", st.stdev(Timelist_DM2))

# Die Machine 3 Time
print("\nDM3 Timelist:", Timelist_DM3)
print("DM3 Mean:", st.mean(Timelist_DM3))
print("DM3 Std Dev:", st.stdev(Timelist_DM3))

# # fit lognormal distribution
# sigma, loc, scale = scipy.stats.lognorm.fit(Timelist)
# lognormal_test = scipy.stats.kstest(Timelist, scipy.stats.lognorm.cdf, args=(sigma, loc, scale))


# # fit gamma distribution
# shape, loc, scale = scipy.stats.gamma.fit(Timelist)
# gamma_test = scipy.stats.kstest(Timelist, scipy.stats.gamma.cdf, args=(shape, loc, scale))

# # fit beta distribution
# a, b, loc, scale = scipy.stats.beta.fit(Timelist)
# beta_test = scipy.stats.kstest(Timelist, scipy.stats.beta.cdf, args=(a, b, loc, scale))


# print(beta_test.statistic)
# print(lognormal_test.statistic)
# print(gamma_test.statistic)




# print(stdtime)
# print(meantime)
# s= abs(np.random.normal(meantime, stdtime, 20))
# normal_std = np.sqrt(np.log(1 + (stdtime/meantime)**2))
# normal_mean = np.log(meantime) - normal_std**2 / 2
# hs = np.random.lognormal(normal_mean, normal_std, 20)
# p=np.random.poisson(meantime, 20)


# print(hs.max())    
# print(hs.mean())   
# print(hs.std())    
# plt.plot(Timelist, color="blue")
# plt.plot(s, color="green")
# plt.plot(hs, color="gold")
# plt.plot(p, color="red")
# plt.plot(b, color= "orange")


totalavgtmean=392.69;
m1avgtmean=371.952
m2avgtmean=183
m3avgtmean=1038
totalavgdmean=597.375
m1davgtmean=616
m2davgtmean=400.8
m1davgtmean=686.375



