import time
import os
from contextlib import contextmanager
import logging
import random

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()

def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data

def WriteFile(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

def WaitForTaskWBAM1():  
    """Waits to be assigned a task from the WireBonder"""
    print("WBAM1 Actuator Current_Activity: WaitForTaskWBAM1")  
    while True:
        AvailWBM1 = ReadFile("AvailWBM1.txt")
        try:
            AvailWBM1 = int(AvailWBM1)
        except ValueError:
            print("Invalid data in AvailWBM1.txt. Waiting for valid data.") 
            time.sleep(1)
            continue
        
        if AvailWBM1 == 1:
            WriteFile("AvailWBM1.txt", "0") 
            WriteFile("AvailWBAM1.txt", "1") 
            PerformWireBonding()

def PerformWireBonding():
    """Performs wire bonding."""
    print("WBAM1 Actuator Current_Activity: Performing wire bonding")  
    #85% is good quality , 10% is decent quality 2, 5% is terrible quality 3
    percentage= random.randint(0,100);
    if percentage <= 85:
        time.sleep(5)  # Simulate the time taken for wire bonding
        quality="1";
        WriteFile("AvailWBAM1.txt", "0")  
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1()  
    if percentage >90:
        time.sleep(12)
        quality="2";
        WriteFile("AvailWBAM1.txt", "0")  
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1()  
    if percentage > 85 and percentage <= 90:
        time.sleep(8)
        quality="3";
        WriteFile("AvailWBAM1.txt", "0") 
        WriteFile("QualityM1.txt", quality)
        WaitForTaskWBAM1()  


if __name__ == "__main__":
    WaitForTaskWBAM1()  