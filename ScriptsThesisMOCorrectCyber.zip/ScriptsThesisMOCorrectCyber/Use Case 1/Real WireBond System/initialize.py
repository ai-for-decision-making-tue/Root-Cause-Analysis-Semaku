import os
import logging

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
#Initialize AvailWBAM1 and AvailWBAM2 as 0
def InitializeAvailWBAM1():
    if not os.path.exists("AvailWBAM1.txt"):
        with open("AvailWBAM1.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailWBAM1.txt with AvailWBAM1 = 0.")

def InitializeAvailWBAM2():
    if not os.path.exists("AvailWBAM2.txt"):
        with open("AvailWBAM2.txt", 'w') as file:
            file.write('0')
        logging.info("Initialized AvailWBAM2.txt with AvailWBAM2 = 0.")

if __name__ == "__main__":
    InitializeAvailWBAM1()
    InitializeAvailWBAM2()
