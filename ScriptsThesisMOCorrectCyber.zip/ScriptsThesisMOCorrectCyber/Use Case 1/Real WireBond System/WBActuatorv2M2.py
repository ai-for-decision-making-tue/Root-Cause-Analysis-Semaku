import time
import os
from contextlib import contextmanager
import logging
import random

# Set up logging configuration
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    file = open(filepath, mode)
    try:
        yield file
    finally:
        file.close()

def ReadFileWithVersion(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            data = file.read().strip()
    except FileNotFoundError:
        data = "0"
    except ValueError:
        data = "0"
    return data

def WriteFileWithVersion(filepath, data):
    with OpenFile(filepath, 'w') as file:
        file.write(data)

def WaitForTaskWBAM2():
    """Waits to be assigned a task from the WireBonder."""
    print("WBAM2 Actuator Current_Activity: WaitForTaskWBAM2")
    while True:
        AvailWBM2 = ReadFileWithVersion("AvailWBM2.txt")
        try:
            AvailWBM2 = int(AvailWBM2)
        except ValueError:
            print("Invalid data in AvailWBM2.txt. Waiting for valid data.")
            time.sleep(1)
            continue
        
        if AvailWBM2 == 1:
            WriteFileWithVersion("AvailWBM2.txt", "0")
            WriteFileWithVersion("AvailWBAM2.txt", "1")
            PerformWireBonding()

def PerformWireBonding():
    """Performs wire bonding."""
    print("WBAM2 Actuator Current_Activity: Performing wire bonding")
    percentage= random.randint(0,100);
    #80% is good quality , 12.5% is decent quality 2, 7.55% is terrible quality 3
    if percentage <= 80:
        time.sleep(5)  # Simulate the time taken for wire bonding
        quality="1";
        WriteFileWithVersion("AvailWBAM2.txt", "0")
        WriteFileWithVersion("QualityM2.txt", quality)
        WaitForTaskWBAM2()

    if percentage >92.5:
        time.sleep(12)
        quality="3";
        WriteFileWithVersion("AvailWBAM2.txt", "0")
        WriteFileWithVersion("QualityM2.txt", quality)
        WaitForTaskWBAM2()

    if percentage > 80 and percentage <= 92.5:
        time.sleep(8)
        quality="2";
        WriteFileWithVersion("AvailWBAM2.txt", "0")
        WriteFileWithVersion("QualityM2.txt", quality)
        WaitForTaskWBAM2()


if __name__ == "__main__":
    WaitForTaskWBAM2()
