import socket
from contextlib import contextmanager
import time
import threading
import os
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise

def RetryOperation(operation, max_retries=10, delay=1):
    for attempt in range(max_retries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}. Retrying in {delay} seconds...")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None

def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None

def WriteFile(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)


def ReadWBSM1():
    return RetryOperation(lambda: ReadFile("AvailWBSM1.txt"))

def ReadWBSM2():
    return RetryOperation(lambda: ReadFile("AvailWBSM2.txt"))

def ReadQM1():
    return RetryOperation(lambda: ReadFile("QualityM1.txt"))

def ReadQM2():
    return RetryOperation(lambda: ReadFile("QualityM2.txt"))

def SendAvailWBSM1(status,quality):
    try:
        jade_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        jade_socket.settimeout(10)
        jade_socket.connect(('localhost', 54321))
        message = f"AvailWBSM1 status: {status},{quality}\n"
        jade_socket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailWBSM1 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        jade_socket.close()

def SendAvailWBSM2(status,quality):
    try:
        jade_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        jade_socket.settimeout(10)
        jade_socket.connect(('localhost', 54323))
        message = f"AvailWBSM2 status: {status},{quality}\n"
        jade_socket.sendall(message.encode('utf-8'))
        logging.info(f"Sent AvailWBSM2 status to JADE agent: {status}")
    except (ConnectionRefusedError, TimeoutError) as e:
        logging.error(f"Error sending status to JADE: {e}")
    finally:
        jade_socket.close()

def UpdateDWBM1(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDWBM1.txt", str(DWBAvail)))

def UpdateDWBM2(DWBAvail):
    RetryOperation(lambda: WriteFile("AvailDWBM2.txt", str(DWBAvail)))

def listen_for_jade_updates():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(('localhost', 54322))
    server_socket.listen(1)  

    logging.info("Listening for JADE agent updates on port 54322")

    while True:
        try:
            client_socket, addr = server_socket.accept()
            logging.info(f"Connection established with {addr}")

            data = client_socket.recv(1024).decode('utf-8').strip()
            logging.info(f"Received data: {data}")

            if data.startswith("Current AvailDWBM1 value: "):
                try:
                    avail_dwbm1 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDWBM1 value: {avail_dwbm1}")
                    UpdateDWBM1(avail_dwbm1)
                except ValueError:
                    logging.error("Error parsing AvailDWBM1 value from the received data.")
            elif data.startswith("Current AvailDWBM2 value: "):
                try:
                    avail_dwbm2 = int(data.split(": ")[1].strip())
                    logging.info(f"Parsed AvailDWBM2 value: {avail_dwbm2}")
                    UpdateDWBM2(avail_dwbm2)
                except ValueError:
                    logging.error("Error parsing AvailDWBM2 value from the received data.")

            client_socket.close()

        except Exception as e:
            logging.error(f"Error in listen_for_jade_updates: {e}")

def MonitorWBSChange():
    LastAvailWBSM1 = None
    LastAvailWBSM2 = None
    
    while True:
        AvailWBSM1 = ReadWBSM1()
        AvailWBSM2 = ReadWBSM2()
        QM1= ReadQM1()
        QM2=ReadQM2()

        if AvailWBSM1 is not None:
            if LastAvailWBSM1 != AvailWBSM1:
   #             logging.info(f"AvailWBSM1 has changed; new value is: {AvailWBSM1}")
                SendAvailWBSM1(AvailWBSM1,QM1)
                LastAvailWBSM1 = AvailWBSM1
         #   else:
         #       logging.info("No change in AvailWBSM1 value.")

        if AvailWBSM2 is not None:
            if LastAvailWBSM2 != AvailWBSM2:
    #            logging.info(f"AvailWBSM2 has changed; new value is: {AvailWBSM2}")
                SendAvailWBSM2(AvailWBSM2,QM2)
                LastAvailWBSM2 = AvailWBSM2
        #    else:
         #       logging.info("No change in AvailWBSM2 value.")

        time.sleep(2)

if __name__ == "__main__":
    try:
        jade_listener_thread = threading.Thread(target=listen_for_jade_updates, daemon=True)
        jade_listener_thread.start()
        
        logging.info("Starting MonitorWBSChange")
        MonitorWBSChange()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
