import time
import os
from contextlib import contextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise

def RetryOperation(operation, maxretries=10, delay=0.6):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None  

def ReadFromFile(filepath):
    return RetryOperation(lambda: ReadFileContents(filepath))

def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFileContents(filepath, content))

def ReadFileContents(filepath):
    with OpenFile(filepath, 'r') as file:
        return file.read().strip()

def WriteFileContents(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)

def MonitorWireBondEnvironment():
    """Monitors the wire bond environment and updates AvailWBSM2.txt based on AvailWBAM2.txt."""
    logging.info("WBSM2 Sensor Current_Activity: Monitor wire bond environment")
    while True:
        AvailWBAM2 = RetryOperation(lambda: int(ReadFromFile("AvailWBAM2.txt")))

        if AvailWBAM2 is None:
            logging.warning("Failed to read AvailWBAM2.txt. Retrying...")
            time.sleep(1)
            continue
        
        if AvailWBAM2 == 1:
            WriteToFile("AvailWBSM2.txt", "0")
            logging.info("Set AvailWBSM2.txt to 0")

        elif AvailWBAM2 == 0:
            WriteToFile("AvailWBSM2.txt", "1")
            logging.info("Set AvailWBSM2.txt to 1")

        time.sleep(1)

if __name__ == "__main__":
    MonitorWireBondEnvironment()
