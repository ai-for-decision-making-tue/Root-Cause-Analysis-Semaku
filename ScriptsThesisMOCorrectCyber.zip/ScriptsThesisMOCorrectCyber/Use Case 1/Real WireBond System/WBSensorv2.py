import time
import os
from contextlib import contextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')



@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise

def RetryOperation(operation, maxretries=10, delay=0.2):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None 

def ReadFromFile(filepath):
    return RetryOperation(lambda: ReadFileContents(filepath))

def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFileContents(filepath, content))

def ReadFileContents(filepath):
    with OpenFile(filepath, 'r') as file:
        return file.read().strip()

def WriteFileContents(filepath, content):
    with OpenFile(filepath, 'w') as file:
        file.write(content)

def MonitorWireBondEnvironment():
    """Monitors the wire bond environment and updates AvailWBSM1.txt based on AvailWBAM1.txt."""
    logging.info("WBSM1 Sensor Current_Activity: Monitor wire bond environment")
    while True:
        AvailWBAM1 = RetryOperation(lambda: int(ReadFromFile("AvailWBAM1.txt")))

        if AvailWBAM1 is None:
            logging.warning("Failed to read AvailWBAM1.txt. Retrying")
            time.sleep(1)
            continue
        
        if AvailWBAM1 == 1:
            WriteToFile("AvailWBSM1.txt", "0")
            logging.info("Set AvailWBSM1.txt to 0")

        elif AvailWBAM1 == 0:
            WriteToFile("AvailWBSM1.txt", "1")
            logging.info("Set AvailWBSM1.txt to 1")

        time.sleep(1)

if __name__ == "__main__":
    MonitorWireBondEnvironment()
