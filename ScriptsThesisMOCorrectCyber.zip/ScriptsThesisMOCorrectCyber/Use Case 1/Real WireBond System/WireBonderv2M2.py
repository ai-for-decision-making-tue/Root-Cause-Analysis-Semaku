import time
import os
from contextlib import contextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise

def RetryOperation(operation, maxretries=10, delay=1):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}.")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None


def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None

def WriteFile(filepath, content):
    try:
        with OpenFile(filepath, 'w') as file:
            file.write(content)
    except IOError as e:
        logging.error(f"Error writing to {filepath}: {e}")

def ReadFromFile(filepath):
    return RetryOperation(lambda: ReadFile(filepath))

def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFile(filepath, content))

def InitializeAvailWBM2():
    if not os.path.exists("AvailWBM2.txt"):
        WriteToFile("AvailWBM2.txt", "0")
        logging.info("Initialized AvailWBM2.txt with AvailWBM2 = 0.")

def WaitForTaskWBM2():
    """Waits to be assigned a task from the WireBonder (AvailDWBM2 > 0)."""
    logging.info("WireBonder Current_Activity: Waiting for task WBM2")
    while True:
        AvailDWBM2 = ReadFromFile("AvailDWBM2.txt")
        if AvailDWBM2 is None:
            logging.error("Failed to read AvailDWBM2.txt. Retrying")
            time.sleep(1)
            continue
        
        if AvailDWBM2 == 1:
            WriteToFile("AvailDWBM2.txt", "0")
            ScheduleTaskWBActuator()  # Proceed to the next activity

def ScheduleTaskWBActuator():
    """Schedules the WBActuator task and updates AvailWBM2.txt."""
    logging.info("WireBonder Current_Activity: Scheduling task WBActuator")
    time.sleep(2)
    WriteToFile("AvailWBM2.txt", "1")
    WaitForTaskWBM2()  # Continue waiting for tasks

if __name__ == "__main__":
    try:
        InitializeAvailWBM2()  # Initialize AvailWBM2.txt
        WaitForTaskWBM2()      # Start waiting for task WBM2
    except Exception as e:
        logging.error(f"An error occurred: {e}")
