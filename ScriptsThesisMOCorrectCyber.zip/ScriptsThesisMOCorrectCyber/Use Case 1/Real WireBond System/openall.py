import subprocess
import os
import time

# List of files to delete
DeletedFiles = [
    r"C:\RealWireBonderPython\AvailDWBM1.txt",
    r"C:\RealWireBonderPython\AvailDWBM2.txt",
    r"C:\RealWireBonderPython\AvailWBAM1.txt",
    r"C:\RealWireBonderPython\AvailWBAM2.txt",
    r"C:\RealWireBonderPython\AvailWBM1.txt",
    r"C:\RealWireBonderPython\AvailWBM2.txt",
    r"C:\RealWireBonderPython\AvailWBSM1.txt",
    r"C:\RealWireBonderPython\AvailWBSM2.txt"
]

# Function to delete files
def DeleteFiles(files):
    for file in files:
        try:
            if os.path.exists(file):
                os.remove(file)
                print(f"Deleted {file}")
            else:
                print(f"{file} does not exist, skipping.")
        except Exception as e:
            print(f"Error deleting {file}: {e}")

# List of paths to the Python scripts
scripts = [
    r"C:\RealWireBonderPython\PythonCommunicatorv2.py",
    r"C:\RealWireBonderPython\WBActuatorv2.py",
    r"C:\RealWireBonderPython\WBActuatorv2M2.py",
    r"C:\RealWireBonderPython\WBSensorv2.py",
    r"C:\RealWireBonderPython\WBSensorv2M2.py",
    r"C:\RealWireBonderPython\WireBonderv2.py",
    r"C:\RealWireBonderPython\WireBonderv2M2.py",
    r"C:\RealWireBonderPython\initialize.py"  
]

# Function to run each script in a separate window 
def RunScripts():
    DeleteFiles(DeletedFiles)
    
    # Run the initialization script first
    init_script = scripts.pop()
    subprocess.Popen(['start', 'cmd', '/k', 'python', init_script], shell=True)
    time.sleep(1)  
    # Run the remaining scripts
    for script in scripts:
        subprocess.Popen(['start', 'cmd', '/k', 'python', script], shell=True)

if __name__ == "__main__":
    RunScripts()
