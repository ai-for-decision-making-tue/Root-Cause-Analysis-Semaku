import time
import os
from contextlib import contextmanager
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
#Open file functions
@contextmanager
def OpenFile(filepath, mode='r'):
    try:
        with open(filepath, mode) as file:
            yield file
    except IOError as e:
        logging.error(f"Error opening file {filepath}: {e}")
        raise

def RetryOperation(operation, maxretries=10, delay=1):
    for attempt in range(maxretries):
        try:
            return operation()
        except (IOError, ValueError) as e:
            logging.warning(f"Operation failed with error: {e}. Retrying in {delay} seconds")
            time.sleep(delay)
    logging.error("Max retries reached. Operation failed.")
    return None

#Read file function
def ReadFile(filepath):
    try:
        with OpenFile(filepath, 'r') as file:
            content = file.read().strip()
            if content == "":
                logging.warning(f"{filepath} is empty. Waiting for valid data.")
                return None
            return int(content)
    except FileNotFoundError:
        logging.warning(f"{filepath} does not exist. Waiting for initialization.")
        return None
    except ValueError:
        logging.warning(f"Invalid data in {filepath}. Waiting for valid data.")
        return None
#Write in file function
def WriteFile(filepath, content):
    try:
        with OpenFile(filepath, 'w') as file:
            file.write(content)
    except IOError as e:
        logging.error(f"Error writing to {filepath}: {e}")

def ReadFromFile(filepath):
    return RetryOperation(lambda: ReadFile(filepath))

def WriteToFile(filepath, content):
    RetryOperation(lambda: WriteFile(filepath, content))

def InitializeAvailWBM1():
    if not os.path.exists("AvailWBM1.txt"):
        WriteToFile("AvailWBM1.txt", "0")
        logging.info("Initialized AvailWBM1.txt with AvailWBM1 = 0.")

def WaitForTaskWBM1():
    """Waits to be assigned a task from the WireBonder (AvailDWBM1 > 0)."""
    logging.info("WireBonder Current_Activity: Waiting for task WBM1")
    while True:
        AvailDWBM1 = ReadFromFile("AvailDWBM1.txt")
        if AvailDWBM1 is None:
            logging.error("Failed to read AvailDWBM1.txt. Retrying")
            time.sleep(1)
            continue
        
        if AvailDWBM1 == 1:
            WriteToFile("AvailDWBM1.txt", "0")
            ScheduleTaskWBActuator()  # Proceed to the next activity

def ScheduleTaskWBActuator():
    """Schedules the WBActuator task and updates AvailWBM1.txt."""
    logging.info("WireBonder Current_Activity: Scheduling task WBActuator")
    time.sleep(2)
    WriteToFile("AvailWBM1.txt", "1")
    WaitForTaskWBM1()  # Continue waiting for tasks

if __name__ == "__main__":
    try:
        InitializeAvailWBM1()  # Initialize AvailWBM1.txt
        WaitForTaskWBM1()      # Start waiting for task WBM1
    except Exception as e:
        logging.error(f"An error occurred: {e}")
